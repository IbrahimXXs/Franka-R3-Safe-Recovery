"""Create a 12-slide English research talk plus three untimed appendix pages.

Charts use the archived experiment data. Scene images replay recorded poses.
The PDF keeps chart geometry and diagram/text objects as vector content.
"""
from pathlib import Path
import hashlib
import json
import math
from html import escape

from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader, PdfWriter, Transformation

BASE = Path(__file__).resolve().parent
ROOT = next(p for p in BASE.parents if (p/'research/forge_budget.py').is_file())
OUT = ROOT/'output/pdf'
OUT.mkdir(parents=True, exist_ok=True)
FIG = BASE/'figures'
SCENE = BASE/'scene'
W, H = 960., 540.
NAVY = HexColor('#17324D')
TEAL = HexColor('#008D84')
RED = HexColor('#C74349')
AMBER = HexColor('#AF7426')
MUTED = HexColor('#566879')
LINE = HexColor('#CED8E1')
PALE = HexColor('#F0F5F7')
GREEN = HexColor('#E5F2EE')

FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Sans', 'DejaVuSans.ttf'), ('Sans-Bold', 'DejaVuSans-Bold.ttf'),
                   ('Sans-Oblique', 'DejaVuSans.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR/file)))
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='Sans-Bold', italic='Sans-Oblique')

PAGES = []
PLACEMENTS = []
TIMES = [25, 50, 50, 65, 50, 65, 45, 50, 45, 45, 65, 45]
assert sum(TIMES) == 600
BASE_PDF = BASE/'talk_base.pdf'
C = canvas.Canvas(str(BASE_PDF), pagesize=(W,H), pageCompression=1)
C.setTitle('Preventing Insertion-Induced Jamming')
C.setAuthor('Franka Safe Recovery Research Project')
C.setSubject('Motion planning and control: simulation proof of concept and research plan')


def text(x, y, value, size=18, color=NAVY, bold=False):
    """Top-left coordinates, baseline at y + font size."""
    C.setFont('Sans-Bold' if bold else 'Sans', size)
    C.setFillColor(color)
    C.drawString(x, H-y-size, value)


def para(x, y, value, width, size=18, color=NAVY, leading=None, bold=False):
    style = ParagraphStyle('p', fontName='Sans-Bold' if bold else 'Sans', fontSize=size,
                           leading=leading or size*1.32, textColor=color,
                           spaceBefore=0, spaceAfter=0)
    p = Paragraph(value, style)
    _, height = p.wrap(width, H)
    if y+height > H-25:
        raise ValueError(f'Paragraph overflows page {len(PAGES)}: {value[:60]}')
    p.drawOn(C, x, H-y-height)
    return height


def line(x1,y1,x2,y2,color=LINE,width=1):
    C.setStrokeColor(color); C.setLineWidth(width)
    C.line(x1,H-y1,x2,H-y2)


def rect(x,y,w,h,fill=PALE,stroke=None,linewidth=1):
    C.setFillColor(fill)
    C.setStrokeColor(stroke or fill); C.setLineWidth(linewidth)
    C.rect(x,H-y-h,w,h,fill=1,stroke=bool(stroke))


def arrow(x1,y1,x2,y2,color=MUTED,width=1.6,head=7):
    line(x1,y1,x2,y2,color,width)
    angle=math.atan2(y2-y1,x2-x1)
    p=C.beginPath();p.moveTo(x2,H-y2)
    for a in (angle+2.6,angle-2.6):
        p.lineTo(x2+head*math.cos(a),H-(y2+head*math.sin(a)))
    p.close();C.setFillColor(color);C.drawPath(p,fill=1,stroke=0)


def node(x,y,w,h,title,subtitle='',color=NAVY):
    rect(x,y,w,h,white,color,1.2)
    para(x+12,y+11,title,w-24,17,color,bold=True)
    if subtitle:para(x+12,y+38,subtitle,w-24,13.5,MUTED)


def image(path,x,y,w,h):
    reader=ImageReader(str(path));iw,ih=reader.getSize()
    scale=min(w/iw,h/ih);dw,dh=iw*scale,ih*scale
    C.drawImage(reader,x+(w-dw)/2,H-y-(h+dh)/2,dw,dh,mask='auto')


def chart(name,x,y,w,h):
    path=FIG/(name+'.pdf')
    r=PdfReader(path);box=r.pages[0].mediabox
    iw,ih=float(box.width),float(box.height)
    scale=min(w/iw,h/ih);dw,dh=iw*scale,ih*scale
    PLACEMENTS.append(dict(page=len(PAGES)-1,path=str(path),scale=scale,
                           x=x+(w-dw)/2,y=H-y-(h+dh)/2))


def footer(source='', page=None):
    line(44,508,916,508)
    if source:text(44,516,source,9.4,MUTED)
    text(881,514,page or f'{len(PAGES):02d} / 12',10,MUTED)


def start(title,section,notes='',appendix=False):
    if PAGES:C.showPage()
    PAGES.append(dict(number=len(PAGES)+1,title=title,section=section,
                      seconds=0 if appendix else TIMES[len(PAGES)],speaker_notes=notes))
    rect(0,0,W,H,white)
    text(44,22,section.upper(),10.5,TEAL,bold=True)
    text(44,43,title,31,NAVY,bold=True)


def takeaway(value,y=451,color=TEAL):
    line(44,y,916,y,color,1.7)
    para(44,y+13,value,872,18,color,bold=True)


# 01: 25 seconds
start('Preventing insertion-induced jamming','Motion Planning and Control',
      'The primary objective is an insertion planning and control policy that avoids insertion-induced jamming. The secondary objective, if progress becomes blocked, is to adjust the pose and restore withdrawability within the available operation-force budget. Existing experiments establish a useful adverse scenario and preliminary recovery feasibility; they do not validate a preventive insertion policy.')
rect(0,0,W,H,white)
text(44,38,'MOTION PLANNING AND CONTROL',12,TEAL,True)
para(44,112,'Preventing<br/>insertion-induced<br/>jamming',369,36,NAVY,leading=44,bold=True)
para(46,282,'First avoid risky insertion.<br/>Then restore a force-limited exit.',370,19,MUTED)
image(SCENE/'bench_reference.png',426,92,500,332)
line(44,388,351,388,TEAL,2)
text(44,414,'Research progress and technical roadmap',15,MUTED)
text(44,441,'September 2026',13,MUTED)
footer('Robot image: recorded-state replay in Isaac Sim. Visualization only.')

# 02: 50 seconds
start('Prevention first, recovery second','Research priorities',
      'First develop the insertion operation policy: choose pose, speed and compliance to avoid jam-prone states. Next, when progress is blocked, adjust posture to restore withdrawability under a bounded operation force, including both adjustment and extraction. The intended hardware is a metal peg and tight plastic socket. Limited grip and part strength motivate task budgets, but the current rigid model and raw wrist signal do not implement fracture or calibrated grip capacity. The cutaway exaggerates clearance for explanation.')
text(48,103,'Preserve a feasible exit throughout insertion',21,NAVY,True)
# Deliberately labeled explanatory cutaway, with two jaw forces and withdrawal.
rect(117,252,90,147,HexColor('#DCE5EB'))
rect(246,252,90,147,HexColor('#DCE5EB'))
rect(117,381,219,18,HexColor('#DCE5EB'))
C.saveState();C.translate(226,H-320);C.rotate(-5)
C.setFillColor(HexColor('#7297AB'));C.rect(-14,-45,28,190,stroke=0,fill=1)
C.restoreState()
rect(157,165,46,46,NAVY);rect(250,165,46,46,NAVY)
arrow(126,188,184,188,TEAL,2);arrow(327,188,269,188,TEAL,2)
text(102,155,'N_L',15,TEAL);text(319,155,'N_R',15,TEAL)
arrow(226,151,226,126,RED,2)
text(242,126,'withdrawal',14,RED)
para(116,413,'Peg and socket cutaway<br/>Schematic, clearance enlarged',254,12,MUTED)
para(434,146,'01  Avoid insertion-induced jamming',470,19,TEAL,bold=True)
para(434,184,'Choose pose, speed and compliance<br/>before a risky contact state develops.',470,17,MUTED)
para(434,257,'02  Restore withdrawability',470,20,NAVY,bold=True)
para(434,296,'If progress is blocked, adjust posture<br/>and withdraw within the operation-force budget.',470,17,MUTED)
para(434,378,'Why bounded force?',470,18,NAVY,bold=True)
para(434,410,'Limited grip and part strength motivate the constraint.<br/>Exploratory wrist budgets: 3 / 4 / 5 N, torque ≤ 1 N·m.',470,14.5,MUTED)
footer('Current raw wrist budget is a task proxy. Grip capacity and allowable part loads still require calibration. [D1]')

# 03: 50 seconds
start('Research context','Selected literature',
      'Assembly and extraction mechanics connect geometry, contact and compliance. Our primary question is how an insertion policy avoids risky contact states before a jam develops. Force-limited recovery is the secondary objective. Contact-aware optimization, impedance control and sim-to-real assembly provide candidate tools, not evidence that our measured forces are physically calibrated or that prevention has been validated.')
rows=[('Contact and extraction','Geometry, friction and compliance shape mating forces.','Whitney 1982 [1]\nGoli et al. 2024 [2]'),
      ('Interaction control','Virtual stiffness and damping shape contact response.','Hogan 1985 [3]'),
      ('Planning through contact','Trajectory optimization can include changing contact modes.','Posa et al. 2014 [4]'),
      ('Safety and transfer','Predictive filtering and calibrated deployment address model risk.','Wabersich 2021 [8]\nIndustReal 2023 [6]')]
for i,(a,b,r) in enumerate(rows):
    y=116+i*76
    text(48,y,a,18,NAVY,True)
    para(318,y,b,360,16.3,MUTED)
    para(711,y,r.replace('\n','<br/>'),204,13.4,TEAL)
    line(48,y+61,913,y+61)
takeaway('First avoid risky insertion. Then restore an exit within the force budget.',445)
footer('Selected primary literature, not an exhaustive novelty claim. Full references in the appendix.')

# 04: 65 seconds
start('Plan insertion to preserve a feasible exit','Course concepts',
      'Represent joint and task states together with pose and force history. The primary planner should advance insertion while avoiding jam-prone states and retaining a predicted feasible exit. If progress is blocked, switch objectives to restoring withdrawability within the force budget. This planning capability is proposed. The existing controller maps Cartesian pose error to joint torques using a Jacobian transpose and null-space term. Recovery feasibility remains policy-specific, not a claim of global physical irrecoverability.')
node(44,112,211,77,'State and history','q, q̇, depth, tilt, wrench')
node(306,112,245,77,'Insertion policy','pose, speed and compliance')
node(602,112,312,77,'Feedback control','Cartesian reference to joint torque')
arrow(255,150,305,150);arrow(551,150,601,150)
text(48,219,'Kinematics and interaction control',20,NAVY,True)
para(48,256,'τ = J(q)<super>T</super>(K<sub>p</sub>e - K<sub>d</sub>ẋ) + τ<sub>null</sub>',850,25,TEAL)
para(48,295,'Existing task-space PD law, simplified. e is the position/orientation error.',860,15,MUTED)
text(48,344,'Primary objective',19,NAVY,True)
para(285,337,'Advance insertion while avoiding jam-risk states<br/>and retaining a predicted feasible exit.',609,18,NAVY)
takeaway('If progress is blocked: restore an exit within the force budget.',439)
footer('Current controller: local FORGE/Factory code. Constrained optimization and predictive filtering are proposed. [3,4,8]')

# 05: 50 seconds
start('Current testbed and recovery probes','Testbed and protocol',
      'Show the actual recorded states in the unchanged simulation scene. The reference reaches a depth gate before applying tilt for one second. Then STOP holds the attained pose, and a chosen policy retreats directly or recenters and realigns. Each policy runs in an independent process; the complete recorded reference prefix is compared offline. The budget starts at recorded reference time zero and excludes preparation.')
texts=[('Reference state','18.228 mm depth, 1.439° tilt','closeup_reference.png'),
       ('Recentered and realigned','18.076 mm depth, 0.170° tilt','closeup_realigned.png'),
       ('Clearance','-3.009 mm depth, 0.063° tilt','closeup_clear.png')]
for i,(title,detail,img) in enumerate(texts):
    x=44+i*294
    image(SCENE/img,x,113,284,174)
    text(x,295,title,16,NAVY,True)
    text(x,323,detail,12.6,MUTED)
labels=[('INSERT','depth gate'),('TILT + HOLD','1 s + 1 s'),('STOP','0.25 s'),('RECOVER','direct or realign'),('CLEAR','end condition')]
for i,(a,b) in enumerate(labels):
    x=44+i*177
    node(x,373,158,69,a,b,TEAL if i in (3,4) else NAVY)
    if i<4:arrow(x+158,407,x+176,407,head=5)
para(44,460,'Rigid bodies, 0.2 mm radial gap, 25 mm blind hole. Physics and task control: 240 Hz.',868,14.5,MUTED)
footer('Recorded-state replays, same camera. Sampled stop permits overshoot and excludes grasp preparation. [D1,7]')

# 06: 65 seconds
start('Evidence: the exit depends on the motion','Preliminary evidence',
      'Both policies start at the same fully matched reference state. The common full-reference peak, including tilt and hold, is 3.56 N. Direct withdrawal crosses 4 N at 0.721 seconds, while recentering and realignment completes with a 3.75 N full-recovery peak and 1.15 N withdrawal-only peak. The direct record is censored at the first violation. This is an alternative selected at the reference state, not a rescue started after the violation. Different horizontal time scales are explicit.')
para(46,95,'18 mm target depth · μ = 1 · 1.5° command tilt · 4 N budget',865,17,MUTED)
chart('paired_recovery_force',41,132,878,291)
para(46,432,'Matched reference: 2,811 samples per policy · reference peak 3.56 N.',863,17,NAVY,bold=True)
para(46,464,'Direct path stops at first exceedance. This pair motivates prevention; it does not validate it.',868,14.6,MUTED)
footer('Raw traces from independent simulator processes. Equality with the budget is allowed; strictly greater triggers stopping. [D1]')

# 07: 45 seconds
start('The budget changes feasibility','Task-dependent labels',
      'For the same planned physical path, 3 N is too tight even for the reference hold. At 4 N the two recovery strategies separate. At 5 N both complete. The 4 and 5 N direct paths share 174 identical recorded recovery samples up to the 4 N stopping frame. Higher-budget data never fills the missing future of the lower-budget record. Budget must be a model input.')
chart('budget_comparison',48,99,865,322)
takeaway('Recoverability depends on state, candidate policy and the task budget.',439)
footer('The 4 N direct peak is censored. Shared 4/5 N recovery prefix: 174 identical samples, excluding clocks. [D1]')

# 08: 50 seconds
start('Embedding depth changes the recovery cost','Parameter evidence',
      'At the shallower 12 mm target the direct path completes at roughly 0.32 N. The 18 mm direct path reaches the 4.54 N violation. Actual reference tilts differ slightly, so this is a descriptive controlled depth comparison rather than an identical-state force experiment. Realignment can itself add cost: at 12 mm its complete peak exceeds direct withdrawal. The optimizer must evaluate the whole recovery, not only the final pull phase.')
chart('depth_comparison',38,105,559,307)
text(642,117,'18 mm direct path',19,NAVY,True)
text(642,163,'1.105 mm',31,MUTED,True)
para(642,207,'Commanded withdrawal<br/>at the stopping frame',265,16,MUTED)
text(642,280,'0.137 mm',31,RED,True)
para(642,324,'Measured withdrawal<br/>at the same frame',265,16,MUTED)
takeaway('Recovery cost can inform insertion risk. Prevention needs closed-loop tests.',442)
footer('Actual reference tilts: 12 mm case 1.524°; 18 mm case 1.439°. Whole-recovery peaks; 18 mm direct is censored. [D1]')

# 09: 45 seconds
start('A 6° command does not produce a 6° state','Angle extension',
      'The plan now permits targets to six degrees. All 2 to 6 degree branches terminate during the tilt before recovery. For the six-degree target, the last issued command is 3.743 degrees, actual peg tilt is 1.469 degrees, and the force is 4.694 N. The ramp duration stays one second, so larger targets also increase commanded angular speed. These are precursor-risk samples, not high-angle withdrawal tests or a universal angular boundary.')
chart('angle_scan',43,105,873,320)
para(48,439,'6° target: 3.743° last command, 1.469° actual tilt, 4.694 N at stopping.',866,18,NAVY,bold=True)
para(48,469,'Actual state and force history are candidate risk inputs. No high-angle withdrawal was tested.',866,15,MUTED)
footer('Angle extension: 6 conditions, 7 executed branches, 5 untested alternatives. No claimed high-angle extraction force. [D2]')

# 10: 45 seconds
start('A dataset for prevention and recovery','Proposed dataset design',
      'Build insertion histories from actual pose, force, contact, tracking and next commanded action. Future prevention labels should combine persistent restricted progress despite commanded insertion, elevated load, and a separate withdrawal probe. These are candidate operational risk indicators, not certified mechanical jam labels. Distinguish them from policy-conditioned recovery completion and whole-path force cost. Current reference failures have no recovery label; invalid numerics, grip loss, untested actions and stopped futures remain separate. Group shared physical paths across data splits. New insertion trials are required to validate prevention labels.')
node(44,114,251,91,'Insertion history','pose, wrench and tracking<br/>commanded action and budget')
node(345,114,239,91,'Outcome probes','insertion progress<br/>candidate recovery motions')
node(635,114,281,91,'Evidence checks','numerics, grasp, completion<br/>matched histories and censoring')
arrow(295,160,344,160);arrow(584,160,634,160)
line(44,237,916,237)
text(44,260,'01  Insertion-risk targets',19,TEAL,True)
para(44,303,'Persistent stall + elevated load<br/>Cross-check with an exit probe',413,17,MUTED)
text(503,260,'02  Recovery targets',19,NAVY,True)
para(503,303,'Policy-specific exit outcome<br/>Peak load over adjustment and withdrawal',413,17,MUTED)
para(44,381,'Risk indicators require validation. An over-budget probe is policy-specific.',872,17,NAVY)
takeaway('Group shared physical paths together when splitting training and test data.',449)
footer('New insertion trials are needed for prevention labels. Preserve invalid, untested and censored outcomes separately. [D1,D2]')

# 11: 65 seconds
start('A proposed planning and control loop','Technical route',
      'The primary mode selects insertion motions before a jam develops. Pose and force history are candidate predictors of rising insertion risk. A mode supervisor should change the objective to restoring withdrawability if progress becomes blocked. Start with a small library of advancing, recentering, tilting and withdrawing actions, then use constrained local MPC and an uncertainty-aware predictive filter. Adjustments and withdrawal share the operation-force budget. A barrier-function filter is only a later option if contact dynamics and feasibility assumptions are validated. This entire preventive and predictive architecture is proposed, beyond current scripted baselines and sampled stopping.')
node(44,114,183,84,'State estimator','pose and force history')
node(262,114,260,84,'Motion planner','1 insert while avoiding jams<br/>2 restore exit if blocked')
node(557,114,358,84,'Predictive safety filter','model uncertainty and load margin [8]')
arrow(227,156,261,156);arrow(522,156,556,156)
node(557,257,358,83,'Cartesian controller','pose tracking with adjustable compliance [3]')
node(44,257,340,83,'Robot and contact dynamics','kinematics, friction and changing contacts')
arrow(736,198,736,256)
arrow(557,299,385,299)
arrow(135,256,135,200)
text(175,217,'wrench + pose feedback',13,MUTED)
para(44,384,'Hypothesis: pose and force history reveal insertion risk early enough to act.',857,17.5,NAVY)
para(44,417,'Model predictive control (MPC) selects pose and speed under load and exit constraints.',860,16.7,MUTED)
para(44,460,'Control barrier functions (CBFs) [5] require validated dynamics and feasible safety constraints.',865,14.5,MUTED)
footer('PROPOSED. Current baseline: scripted recovery paths, existing task-space PD control and sample-wise stopping. [3,4,5,8]')

# 12: 45 seconds
start('Ready to validate jam-avoiding insertion','Milestones and conclusion',
      'Current experiments demonstrate a useful adverse scenario and preliminary recovery feasibility. The primary prevention objective is not yet validated. First compare baseline insertion against a risk-aware insertion policy under matched disturbances, measuring insertion completion, peak load and later exit cost. This avoids rewarding a policy that merely stops and never inserts. Next evaluate force-limited restoration of withdrawability from matched blocked states, constraining the full adjustment-and-exit path. Numerical sensitivity, calibrated task budgets and hardware transfer are essential across both stages. Separate physics and control frequencies. Rigid-body simulation currently excludes plastic damage and fracture.')
text(48,115,'Demonstrated',20,TEAL,True)
para(270,109,'Scenario: direct exit exceeds 4 N.<br/>Pose adjustment enables an exit within budget.',620,20,NAVY,bold=True)
steps=[('01','Validate prevention','Compare baseline vs risk-aware insertion.<br/>Measure completion, peak load and exit cost.'),
       ('02','Restore withdrawability','Compare recovery paths from matched states.<br/>Constrain the full adjustment-and-exit motion.'),
       ('03','Robustness and transfer','Vary rates, contact settings and disturbances.<br/>Calibrate grip and part limits before hardware trials.')]
for i,(num,title,desc) in enumerate(steps):
    y=215+i*75
    text(48,y,num,24,TEAL,True)
    text(106,y,title,18,NAVY,True)
    para(420,y,desc,470,15.2,MUTED)
    if i<2:line(48,y+61,910,y+61)
takeaway('Recovery feasibility shown. Jam-avoiding insertion remains to be validated.',452)
footer('Peak-based evidence at 240 Hz. Current rigid model excludes plastic damage and fracture; budgets still require calibration.')

# A1: study coverage; outside the ten-minute main talk
start('Complete evidence coverage','Appendix A',
      'Reference for questions. Do not pool deterministic reruns as independent statistical trials. The original budget matrix executed 13 branches. The angle extension executed 7, of which three repeat prior anchors. Both preserve planned but untested alternatives.',True)
chart('condition_outcomes',41,104,877,288)
para(48,411,'[D1] Budget study: 8 conditions, 13 executed branches, 3 untested.',862,17,NAVY)
para(48,442,'[D2] Angle extension: 6 conditions, 7 executed branches, 5 untested.',862,17,NAVY)
para(48,474,'Exploratory deterministic trials. Shared histories and repeated anchors are not independent samples.',862,13.8,MUTED)
footer('Project data: Forge-Budget-V1-20260915 and Forge-Budget-Angle6-20260915. Raw logs and archived sources retained.','A1')

REFS=[
 ('[1] Whitney, D. E. (1982)','Quasi-Static Assembly of Compliantly Supported Rigid Parts.',
  'Journal of Dynamic Systems, Measurement, and Control 104(1):65-77.',
  'https://doi.org/10.1115/1.3149634'),
 ('[2] Goli, F., et al. (2024)','Characterizing the mechanics of rectangular peg-hole disassembly and the effect of the active compliance centre on the extraction force.',
  'Royal Society Open Science 11:240956.', 'https://doi.org/10.1098/rsos.240956'),
 ('[3] Hogan, N. (1985)','Impedance Control: An Approach to Manipulation: Part I - Theory.',
  'Journal of Dynamic Systems, Measurement, and Control 107(1):1-7.', 'https://doi.org/10.1115/1.3140702'),
 ('[4] Posa, M., Cantu, C., and Tedrake, R. (2014)','A direct method for trajectory optimization of rigid bodies through contact.',
  'International Journal of Robotics Research 33(1):69-81.', 'https://doi.org/10.1177/0278364913506757'),
 ('[5] Ames, A. D., Xu, X., Grizzle, J. W., and Tabuada, P. (2017)','Control Barrier Function Based Quadratic Programs for Safety Critical Systems.',
  'IEEE Transactions on Automatic Control 62(8):3861-3876.', 'https://doi.org/10.1109/TAC.2016.2638961'),
 ('[6] Tang, B., et al. (2023)','IndustReal: Transferring Contact-Rich Assembly Tasks from Simulation to Reality.',
  'Robotics: Science and Systems XIX.', 'https://arxiv.org/abs/2305.17110'),
 ('[7] Narang, Y., et al. (2022)','Factory: Fast Contact for Robotic Assembly.',
  'Robotics: Science and Systems XVIII.', 'https://arxiv.org/abs/2205.03532'),
 ('[8] Wabersich, K. P., and Zeilinger, M. N. (2021)','A predictive safety filter for learning-based control of constrained nonlinear dynamical systems.',
  'Automatica 129:109597.', 'https://doi.org/10.1016/j.automatica.2021.109597')]
for part in range(2):
    start('References'+('' if part==0 else ' continued'),'Appendix '+('B' if part==0 else 'C'),'',True)
    for j,(author,title,venue,url) in enumerate(REFS[4*part:4*part+4]):
        y=106+j*97
        text(48,y,author,15.8,NAVY,True)
        ht=para(48,y+25,escape(title),862,13.5,NAVY,leading=17.5)
        para(48,y+27+ht,escape(venue)+f' <link href="{url}" color="#008D84">DOI / paper</link>',862,12,MUTED)
        if j<3:line(48,y+87,911,y+87)
    footer('Primary literature supports the research context and proposed methods. It does not validate local simulated force values.', 'A'+str(part+2))

C.save()

# Embed each chart PDF as vector objects onto its reserved slide area.
reader=PdfReader(BASE_PDF);writer=PdfWriter()
for page in reader.pages:writer.add_page(page)
for placement in PLACEMENTS:
    src=PdfReader(placement['path']).pages[0]
    transform=Transformation().scale(placement['scale']).translate(placement['x'],placement['y'])
    writer.pages[placement['page']].merge_transformed_page(src,transform,over=True)
writer.add_metadata({'/Title':'Preventing Insertion-Induced Jamming',
                     '/Author':'Franka Safe Recovery Research Project',
                     '/Subject':'12-slide, 10-minute research briefing with three appendix pages',
                     '/Keywords':'motion planning, control, peg-in-hole, jamming prevention, force-limited recovery'})
for page in PAGES:
    writer.add_outline_item(page['title'],page['number']-1)
final=OUT/'safe_recovery_motion_planning_control.pdf'
with final.open('wb') as stream:writer.write(stream)
manifest=dict(final_pdf=str(final),pages=len(PAGES),main_slides=12,appendix_pages=3,
              research_priority='First prevent insertion-induced jamming; then restore withdrawability under an operation-force budget.',
              planned_talk_seconds=sum(TIMES),slides=PAGES,chart_placements=PLACEMENTS,
              builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              pdf_sha256=hashlib.sha256(final.read_bytes()).hexdigest())
(BASE/'talk_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['final_pdf','pages','main_slides','appendix_pages','planned_talk_seconds']},indent=2))
