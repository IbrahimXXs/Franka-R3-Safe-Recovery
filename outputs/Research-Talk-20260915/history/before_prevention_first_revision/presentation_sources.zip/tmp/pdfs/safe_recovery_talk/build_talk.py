"""Create a 12-slide English research talk plus three untimed appendix pages.

Charts use the archived experiment data. Scene images replay recorded poses.
The PDF keeps chart geometry and diagram/text objects as vector content.
"""
from pathlib import Path
import hashlib
import json
import math
from html import escape

from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader, PdfWriter, Transformation

BASE = Path(__file__).resolve().parent
ROOT = next(p for p in BASE.parents if (p/'research/forge_budget.py').is_file())
OUT = ROOT/'output/pdf'
OUT.mkdir(parents=True, exist_ok=True)
FIG = BASE/'figures'
SCENE = BASE/'scene'
W, H = 960., 540.
NAVY = HexColor('#17324D')
TEAL = HexColor('#008D84')
RED = HexColor('#C74349')
AMBER = HexColor('#AF7426')
MUTED = HexColor('#566879')
LINE = HexColor('#CED8E1')
PALE = HexColor('#F0F5F7')
GREEN = HexColor('#E5F2EE')

FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Sans', 'DejaVuSans.ttf'), ('Sans-Bold', 'DejaVuSans-Bold.ttf'),
                   ('Sans-Oblique', 'DejaVuSans.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR/file)))
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='Sans-Bold', italic='Sans-Oblique')

PAGES = []
PLACEMENTS = []
TIMES = [25, 50, 50, 65, 50, 65, 45, 50, 45, 45, 65, 45]
assert sum(TIMES) == 600
BASE_PDF = BASE/'talk_base.pdf'
C = canvas.Canvas(str(BASE_PDF), pagesize=(W,H), pageCompression=1)
C.setTitle('Safe Insertion and Recovery Under Load Limits')
C.setAuthor('Franka Safe Recovery Research Project')
C.setSubject('Motion planning and control: simulation proof of concept and research plan')


def text(x, y, value, size=18, color=NAVY, bold=False):
    """Top-left coordinates, baseline at y + font size."""
    C.setFont('Sans-Bold' if bold else 'Sans', size)
    C.setFillColor(color)
    C.drawString(x, H-y-size, value)


def para(x, y, value, width, size=18, color=NAVY, leading=None, bold=False):
    style = ParagraphStyle('p', fontName='Sans-Bold' if bold else 'Sans', fontSize=size,
                           leading=leading or size*1.32, textColor=color,
                           spaceBefore=0, spaceAfter=0)
    p = Paragraph(value, style)
    _, height = p.wrap(width, H)
    if y+height > H-25:
        raise ValueError(f'Paragraph overflows page {len(PAGES)}: {value[:60]}')
    p.drawOn(C, x, H-y-height)
    return height


def line(x1,y1,x2,y2,color=LINE,width=1):
    C.setStrokeColor(color); C.setLineWidth(width)
    C.line(x1,H-y1,x2,H-y2)


def rect(x,y,w,h,fill=PALE,stroke=None,linewidth=1):
    C.setFillColor(fill)
    C.setStrokeColor(stroke or fill); C.setLineWidth(linewidth)
    C.rect(x,H-y-h,w,h,fill=1,stroke=bool(stroke))


def arrow(x1,y1,x2,y2,color=MUTED,width=1.6,head=7):
    line(x1,y1,x2,y2,color,width)
    angle=math.atan2(y2-y1,x2-x1)
    p=C.beginPath();p.moveTo(x2,H-y2)
    for a in (angle+2.6,angle-2.6):
        p.lineTo(x2+head*math.cos(a),H-(y2+head*math.sin(a)))
    p.close();C.setFillColor(color);C.drawPath(p,fill=1,stroke=0)


def node(x,y,w,h,title,subtitle='',color=NAVY):
    rect(x,y,w,h,white,color,1.2)
    para(x+12,y+11,title,w-24,17,color,bold=True)
    if subtitle:para(x+12,y+38,subtitle,w-24,13.5,MUTED)


def image(path,x,y,w,h):
    reader=ImageReader(str(path));iw,ih=reader.getSize()
    scale=min(w/iw,h/ih);dw,dh=iw*scale,ih*scale
    C.drawImage(reader,x+(w-dw)/2,H-y-(h+dh)/2,dw,dh,mask='auto')


def chart(name,x,y,w,h):
    path=FIG/(name+'.pdf')
    r=PdfReader(path);box=r.pages[0].mediabox
    iw,ih=float(box.width),float(box.height)
    scale=min(w/iw,h/ih);dw,dh=iw*scale,ih*scale
    PLACEMENTS.append(dict(page=len(PAGES)-1,path=str(path),scale=scale,
                           x=x+(w-dw)/2,y=H-y-(h+dh)/2))


def footer(source='', page=None):
    line(44,508,916,508)
    if source:text(44,516,source,9.4,MUTED)
    text(881,514,page or f'{len(PAGES):02d} / 12',10,MUTED)


def start(title,section,notes='',appendix=False):
    if PAGES:C.showPage()
    PAGES.append(dict(number=len(PAGES)+1,title=title,section=section,
                      seconds=0 if appendix else TIMES[len(PAGES)],speaker_notes=notes))
    rect(0,0,W,H,white)
    text(44,22,section.upper(),10.5,TEAL,bold=True)
    text(44,43,title,31,NAVY,bold=True)


def takeaway(value,y=451,color=TEAL):
    line(44,y,916,y,color,1.7)
    para(44,y+13,value,872,18,color,bold=True)


# 01: 25 seconds
start('Safe insertion and recovery','Motion Planning and Control',
      'Introduce the finite-load recovery question. Our rigid-body simulator already produces a strategy-dependent proof of concept. The remaining talk distinguishes observed evidence from proposed planning and control methods.')
rect(0,0,W,H,white)
text(44,38,'MOTION PLANNING AND CONTROL',12,TEAL,True)
para(44,112,'Safe insertion<br/>and recovery<br/>under load limits',369,36,NAVY,leading=44,bold=True)
para(46,282,'A simulation proof of concept<br/>for task-aware recovery',370,20,MUTED)
image(SCENE/'bench_reference.png',426,92,500,332)
line(44,388,351,388,TEAL,2)
text(44,414,'Research progress and technical roadmap',15,MUTED)
text(44,441,'September 2026',13,MUTED)
footer('Robot image: recorded-state replay in Isaac Sim. Visualization only.')

# 02: 50 seconds
start('The task needs an affordable exit','Research question',
      'The intended physical setup uses a metal peg and tight plastic socket. Grip friction and part strength motivate a finite allowable load. The current study changes the monitored wrist-force budget, not the actual grip drive. The drawing is an explanatory cutaway with exaggerated clearance.')
text(48,103,'Insert while preserving a feasible recovery',21,NAVY,True)
# Deliberately labeled explanatory cutaway, with two jaw forces and withdrawal.
rect(117,252,90,147,HexColor('#DCE5EB'))
rect(246,252,90,147,HexColor('#DCE5EB'))
rect(117,381,219,18,HexColor('#DCE5EB'))
C.saveState();C.translate(226,H-320);C.rotate(-5)
C.setFillColor(HexColor('#7297AB'));C.rect(-14,-45,28,190,stroke=0,fill=1)
C.restoreState()
rect(157,165,46,46,NAVY);rect(250,165,46,46,NAVY)
arrow(126,188,184,188,TEAL,2);arrow(327,188,269,188,TEAL,2)
text(102,155,'N_L',15,TEAL);text(319,155,'N_R',15,TEAL)
arrow(226,151,226,126,RED,2)
text(242,126,'withdrawal',14,RED)
para(116,413,'Peg and socket cutaway<br/>Schematic, clearance enlarged',254,12,MUTED)
para(434,150,'Limited grip friction',435,21,NAVY,bold=True)
para(434,184,'F<sub>t,max</sub> ≈ μ<sub>g</sub>(N<sub>L</sub> + N<sub>R</sub>)',435,23,TEAL)
para(434,224,'Fragile parts also limit squeeze and bending.',435,17,MUTED)
para(434,278,'Current simulation constraint',435,21,NAVY,bold=True)
para(434,315,'‖F<sub>wrist</sub>‖ ≤ B<sub>F</sub> &nbsp;&nbsp; ‖τ<sub>wrist</sub>‖ ≤ 1 N·m',470,23,TEAL)
para(434,360,'3 / 4 / 5 N are exploratory task budgets.<br/>Grip capacity and fracture limits need calibration.',438,16,MUTED)
footer('Motivation: finite grip and fragile parts. Current signal: simulated raw wrist-force norm. [D1]')

# 03: 50 seconds
start('Research context','Selected literature',
      'Assembly mechanics and extraction mechanics already connect geometry, contact and compliance. Our question is narrower: which recovery stays within a chosen task budget? Contact-aware optimization, impedance control and sim-to-real assembly provide tools, not evidence that our measured forces are physically calibrated.')
rows=[('Contact and extraction','Geometry, friction and compliance shape mating forces.','Whitney 1982 [1]\nGoli et al. 2024 [2]'),
      ('Interaction control','Virtual stiffness and damping shape contact response.','Hogan 1985 [3]'),
      ('Planning through contact','Trajectory optimization can include changing contact modes.','Posa et al. 2014 [4]'),
      ('Safety and transfer','Predictive filtering and calibrated deployment address model risk.','Wabersich 2021 [8]\nIndustReal 2023 [6]')]
for i,(a,b,r) in enumerate(rows):
    y=116+i*76
    text(48,y,a,18,NAVY,True)
    para(318,y,b,360,16.3,MUTED)
    para(711,y,r.replace('\n','<br/>'),204,13.4,TEAL)
    line(48,y+61,913,y+61)
takeaway('Our focus: budget-conditioned recovery with matched insertion histories.',445)
footer('Selected primary literature, not an exhaustive novelty claim. Full references in the appendix.')

# 04: 65 seconds
start('A constrained planning and control problem','Course concepts',
      'Represent the state in joint and task coordinates, including contact history. A local planner chooses position and orientation paths. The existing controller maps Cartesian pose error to joint torques with a Jacobian transpose and a null-space term. The research objective adds task load and grasp constraints. Feasibility is relative to a tested policy, not a claim of global physical irrecoverability.')
node(44,112,211,77,'State and history','q, q̇, depth, tilt, wrench')
node(306,112,245,77,'Motion plan','pose path and contact modes')
node(602,112,312,77,'Feedback control','Cartesian reference to joint torque')
arrow(255,150,305,150);arrow(551,150,601,150)
text(48,219,'Kinematics and interaction control',20,NAVY,True)
para(48,256,'τ = J(q)<super>T</super>(K<sub>p</sub>e - K<sub>d</sub>ẋ) + τ<sub>null</sub>',850,25,TEAL)
para(48,295,'Existing task-space PD law, simplified. e is the position/orientation error.',860,15,MUTED)
text(48,344,'Planning objective',19,NAVY,True)
para(285,337,'Minimize recovery time and control effort<br/>subject to load limits, joint limits and retained grasp.',609,18,NAVY)
takeaway('Policy-specific recoverability: can this path reach clearance within budget?',439)
footer('Current controller: local FORGE/Factory code. Constrained optimization and predictive filtering are proposed. [3,4,8]')

# 05: 50 seconds
start('The simulated experiment','Testbed and protocol',
      'Show the actual recorded states in the unchanged simulation scene. The reference reaches a depth gate before applying tilt for one second. Then STOP holds the attained pose, and a chosen policy retreats directly or recenters and realigns. Each policy runs in an independent process; the complete recorded reference prefix is compared offline. The budget starts at recorded reference time zero and excludes preparation.')
texts=[('Reference state','18.228 mm depth, 1.439° tilt','closeup_reference.png'),
       ('Recentered and realigned','18.076 mm depth, 0.170° tilt','closeup_realigned.png'),
       ('Clearance','-3.009 mm depth, 0.063° tilt','closeup_clear.png')]
for i,(title,detail,img) in enumerate(texts):
    x=44+i*294
    image(SCENE/img,x,113,284,174)
    text(x,295,title,16,NAVY,True)
    text(x,323,detail,12.6,MUTED)
labels=[('INSERT','depth gate'),('TILT + HOLD','1 s + 1 s'),('STOP','0.25 s'),('RECOVER','direct or realign'),('CLEAR','end condition')]
for i,(a,b) in enumerate(labels):
    x=44+i*177
    node(x,373,158,69,a,b,TEAL if i in (3,4) else NAVY)
    if i<4:arrow(x+158,407,x+176,407,head=5)
para(44,460,'Rigid bodies, 0.2 mm radial gap, 25 mm blind hole. Physics and task control: 240 Hz.',868,14.5,MUTED)
footer('Recorded-state replays, same camera. Sampled stop permits overshoot and excludes grasp preparation. [D1,7]')

# 06: 65 seconds
start('A recovery choice changes the outcome','Main proof of concept',
      'Both policies start at the same fully matched reference state. The common full-reference peak, including tilt and hold, is 3.56 N. Direct withdrawal crosses 4 N at 0.721 seconds, while recentering and realignment completes with a 3.75 N full-recovery peak and 1.15 N withdrawal-only peak. The direct record is censored at the first violation. This is an alternative selected at the reference state, not a rescue started after the violation. Different horizontal time scales are explicit.')
para(46,95,'18 mm target depth · μ = 1 · 1.5° command tilt · 4 N budget',865,17,MUTED)
chart('paired_recovery_force',41,132,878,291)
para(46,432,'Matched reference: 2,811 samples per policy · reference peak 3.56 N.',863,17,NAVY,bold=True)
para(46,464,'Direct path: first exceedance, incomplete. Realignment: complete recovery from the matched starting state.',868,14.6,MUTED)
footer('Raw traces from independent simulator processes. Equality with the budget is allowed; strictly greater triggers stopping. [D1]')

# 07: 45 seconds
start('The budget changes feasibility','Task-dependent labels',
      'For the same planned physical path, 3 N is too tight even for the reference hold. At 4 N the two recovery strategies separate. At 5 N both complete. The 4 and 5 N direct paths share 174 identical recorded recovery samples up to the 4 N stopping frame. Higher-budget data never fills the missing future of the lower-budget record. Budget must be a model input.')
chart('budget_comparison',48,99,865,322)
takeaway('Recoverability depends on state, candidate policy and the task budget.',439)
footer('The 4 N direct peak is censored. Shared 4/5 N recovery prefix: 174 identical samples, excluding clocks. [D1]')

# 08: 50 seconds
start('Embedding depth changes the recovery cost','Parameter evidence',
      'At the shallower 12 mm target the direct path completes at roughly 0.32 N. The 18 mm direct path reaches the 4.54 N violation. Actual reference tilts differ slightly, so this is a descriptive controlled depth comparison rather than an identical-state force experiment. Realignment can itself add cost: at 12 mm its complete peak exceeds direct withdrawal. The optimizer must evaluate the whole recovery, not only the final pull phase.')
chart('depth_comparison',38,105,559,307)
text(642,117,'18 mm direct path',19,NAVY,True)
text(642,163,'1.105 mm',31,MUTED,True)
para(642,207,'Commanded withdrawal<br/>at the stopping frame',265,16,MUTED)
text(642,280,'0.137 mm',31,RED,True)
para(642,324,'Measured withdrawal<br/>at the same frame',265,16,MUTED)
takeaway('The adjustment motion has a cost, so realignment is not always preferable.',442)
footer('Actual reference tilts: 12 mm case 1.524°; 18 mm case 1.439°. Whole-recovery peaks; 18 mm direct is censored. [D1]')

# 09: 45 seconds
start('A 6° command does not produce a 6° state','Angle extension',
      'The plan now permits targets to six degrees. All 2 to 6 degree branches terminate during the tilt before recovery. For the six-degree target, the last issued command is 3.743 degrees, actual peg tilt is 1.469 degrees, and the force is 4.694 N. The ramp duration stays one second, so larger targets also increase commanded angular speed. These are precursor-risk samples, not high-angle withdrawal tests or a universal angular boundary.')
chart('angle_scan',43,105,873,320)
para(48,439,'6° target: 3.743° last command, 1.469° actual tilt, 4.694 N at stopping.',866,18,NAVY,bold=True)
para(48,469,'Fixed 1 s ramp also changes angular speed. These branches never entered recovery.',866,15,MUTED)
footer('Angle extension: 6 conditions, 7 executed branches, 5 untested alternatives. No claimed high-angle extraction force. [D2]')

# 10: 45 seconds
start('A dataset for recovery decisions','States, actions and labels',
      'Keep the recorded history, actual state, budget and candidate policy as inputs. A complete safe reference is a prerequisite for recovery labels. Preserve sample-wise forces, contact data, pose tracking, grasp and numerical flags. Distinguish observed budget violation from numerical unknowns, reference failure and untested recovery. Keep stopped trajectories censored and shared paths together across training and test splits.')
node(44,114,251,91,'Condition and history','actual pose, contacts, wrench<br/>budget B and candidate policy')
node(345,114,239,91,'Continuous rollout','reference, adjustment, exit<br/>240 Hz raw observations')
node(635,114,281,91,'Evidence checks','numerics, grasp, completion<br/>full reference matching')
arrow(295,160,344,160);arrow(584,160,634,160)
line(44,237,916,237)
headers=[('Safe clearance',TEAL),('Load violation',RED),('Grasp limit',AMBER),('Unknown / untested',MUTED)]
descs=['Complete exit within budget','Keep the first crossing frame','Keep the separate grasp flag','Missing or invalid evidence']
for i,((head,color),desc) in enumerate(zip(headers,descs)):
    x=44+222*i
    text(x,265,head,17,color,True)
    para(x,301,desc,200,15,MUTED)
para(44,371,'Assign recovery labels only after a valid reference.<br/>Keep unobserved trajectory segments missing.',850,19,NAVY)
takeaway('Group shared physical paths together when splitting training and test data.',449)
footer('Saved CSV, raw contacts, run metadata and source hashes support traceability. Labels describe tested policies. [D1,D2]')

# 11: 65 seconds
start('A proposed planning and control loop','Technical route',
      'Start with a small library of retreat, recentering and orientation actions. Use constrained local MPC to select Cartesian references using a model of the closed-loop interaction. Add an uncertainty-aware predictive safety filter before the Cartesian controller. Later, compare a learned risk ranker and possibly a barrier-function filter only if force dynamics and feasibility assumptions have been validated. This entire predictive architecture is future work, unlike the current scripted baselines and sampled stop.')
node(44,114,183,84,'State estimator','pose and force history')
node(262,114,260,84,'Local motion planner','pose primitives, then MPC [4,8]')
node(557,114,358,84,'Predictive safety filter','model uncertainty and load margin [8]')
arrow(227,156,261,156);arrow(522,156,556,156)
node(557,257,358,83,'Cartesian controller','pose tracking with adjustable compliance [3]')
node(44,257,340,83,'Robot and contact dynamics','kinematics, friction and changing contacts')
arrow(736,198,736,256)
arrow(557,299,385,299)
arrow(135,256,135,200)
text(175,217,'wrench + pose feedback',13,MUTED)
para(44,384,'MPC: model predictive control over depth, lateral offset, tilt and speed.',857,18,NAVY)
para(44,417,'Evaluate predicted peak load and a feasible backup path before applying the next reference.',860,17,MUTED)
para(44,460,'Control barrier functions (CBFs) [5] require validated dynamics and feasible safety constraints.',865,14.5,MUTED)
footer('PROPOSED. Current baseline: scripted recovery paths, existing task-space PD control and sample-wise stopping. [3,4,5,8]')

# 12: 45 seconds
start('Feasibility is established at the concept level','Milestones and conclusion',
      'The proof of concept is complete for strategy-dependent recovery in this sampled rigid-body simulation. Next comes independent numerical sensitivity and calibrated task-force limits, then predictive motion selection with controlled baselines, then transfer to a metal peg and plastic socket. Evaluate peak and sustained loads, completion, overshoot and grasp retention. Force and control frequencies must be varied separately. The current evidence is not a robust or hardware safety certificate.')
text(48,115,'Demonstrated',20,TEAL,True)
para(270,109,'Matched state + 4 N budget:<br/>direct withdrawal exceeds, realignment clears.',620,22,NAVY,bold=True)
steps=[('01','Validate the simulator','Separate physics/control rates.<br/>Check solver, speed and parameter sensitivity.'),
       ('02','Develop predictive recovery','Compare direct, realign and local MPC.<br/>Evaluate unseen path/parameter groups.'),
       ('03','Calibrate and transfer','Measure grip and allowable part loads.<br/>Validate metal-peg / plastic-socket trials.')]
for i,(num,title,desc) in enumerate(steps):
    y=215+i*75
    text(48,y,num,24,TEAL,True)
    text(106,y,title,18,NAVY,True)
    para(420,y,desc,470,15.2,MUTED)
    if i<2:line(48,y+61,910,y+61)
takeaway('Concept verified in simulation. Robustness and hardware validation are next.',452)
footer('Peak-based evidence at 240 Hz. Current rigid model excludes plastic damage and fracture; budgets still require calibration.')

# A1: study coverage; outside the ten-minute main talk
start('Complete evidence coverage','Appendix A',
      'Reference for questions. Do not pool deterministic reruns as independent statistical trials. The original budget matrix executed 13 branches. The angle extension executed 7, of which three repeat prior anchors. Both preserve planned but untested alternatives.',True)
chart('condition_outcomes',41,104,877,288)
para(48,411,'[D1] Budget study: 8 conditions, 13 executed branches, 3 untested.',862,17,NAVY)
para(48,442,'[D2] Angle extension: 6 conditions, 7 executed branches, 5 untested.',862,17,NAVY)
para(48,474,'Exploratory deterministic trials. Shared histories and repeated anchors are not independent samples.',862,13.8,MUTED)
footer('Project data: Forge-Budget-V1-20260915 and Forge-Budget-Angle6-20260915. Raw logs and archived sources retained.','A1')

REFS=[
 ('[1] Whitney, D. E. (1982)','Quasi-Static Assembly of Compliantly Supported Rigid Parts.',
  'Journal of Dynamic Systems, Measurement, and Control 104(1):65-77.',
  'https://doi.org/10.1115/1.3149634'),
 ('[2] Goli, F., et al. (2024)','Characterizing the mechanics of rectangular peg-hole disassembly and the effect of the active compliance centre on the extraction force.',
  'Royal Society Open Science 11:240956.', 'https://doi.org/10.1098/rsos.240956'),
 ('[3] Hogan, N. (1985)','Impedance Control: An Approach to Manipulation: Part I - Theory.',
  'Journal of Dynamic Systems, Measurement, and Control 107(1):1-7.', 'https://doi.org/10.1115/1.3140702'),
 ('[4] Posa, M., Cantu, C., and Tedrake, R. (2014)','A direct method for trajectory optimization of rigid bodies through contact.',
  'International Journal of Robotics Research 33(1):69-81.', 'https://doi.org/10.1177/0278364913506757'),
 ('[5] Ames, A. D., Xu, X., Grizzle, J. W., and Tabuada, P. (2017)','Control Barrier Function Based Quadratic Programs for Safety Critical Systems.',
  'IEEE Transactions on Automatic Control 62(8):3861-3876.', 'https://doi.org/10.1109/TAC.2016.2638961'),
 ('[6] Tang, B., et al. (2023)','IndustReal: Transferring Contact-Rich Assembly Tasks from Simulation to Reality.',
  'Robotics: Science and Systems XIX.', 'https://arxiv.org/abs/2305.17110'),
 ('[7] Narang, Y., et al. (2022)','Factory: Fast Contact for Robotic Assembly.',
  'Robotics: Science and Systems XVIII.', 'https://arxiv.org/abs/2205.03532'),
 ('[8] Wabersich, K. P., and Zeilinger, M. N. (2021)','A predictive safety filter for learning-based control of constrained nonlinear dynamical systems.',
  'Automatica 129:109597.', 'https://doi.org/10.1016/j.automatica.2021.109597')]
for part in range(2):
    start('References'+('' if part==0 else ' continued'),'Appendix '+('B' if part==0 else 'C'),'',True)
    for j,(author,title,venue,url) in enumerate(REFS[4*part:4*part+4]):
        y=106+j*97
        text(48,y,author,15.8,NAVY,True)
        ht=para(48,y+25,escape(title),862,13.5,NAVY,leading=17.5)
        para(48,y+27+ht,escape(venue)+f' <link href="{url}" color="#008D84">DOI / paper</link>',862,12,MUTED)
        if j<3:line(48,y+87,911,y+87)
    footer('Primary literature supports the research context and proposed methods. It does not validate local simulated force values.', 'A'+str(part+2))

C.save()

# Embed each chart PDF as vector objects onto its reserved slide area.
reader=PdfReader(BASE_PDF);writer=PdfWriter()
for page in reader.pages:writer.add_page(page)
for placement in PLACEMENTS:
    src=PdfReader(placement['path']).pages[0]
    transform=Transformation().scale(placement['scale']).translate(placement['x'],placement['y'])
    writer.pages[placement['page']].merge_transformed_page(src,transform,over=True)
writer.add_metadata({'/Title':'Safe Insertion and Recovery Under Load Limits',
                     '/Author':'Franka Safe Recovery Research Project',
                     '/Subject':'12-slide, 10-minute research briefing with three appendix pages',
                     '/Keywords':'motion planning, control, peg-in-hole, safe recovery, force budget'})
for page in PAGES:
    writer.add_outline_item(page['title'],page['number']-1)
final=OUT/'safe_recovery_motion_planning_control.pdf'
with final.open('wb') as stream:writer.write(stream)
manifest=dict(final_pdf=str(final),pages=len(PAGES),main_slides=12,appendix_pages=3,
              planned_talk_seconds=sum(TIMES),slides=PAGES,chart_placements=PLACEMENTS,
              builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              pdf_sha256=hashlib.sha256(final.read_bytes()).hexdigest())
(BASE/'talk_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['final_pdf','pages','main_slides','appendix_pages','planned_talk_seconds']},indent=2))
