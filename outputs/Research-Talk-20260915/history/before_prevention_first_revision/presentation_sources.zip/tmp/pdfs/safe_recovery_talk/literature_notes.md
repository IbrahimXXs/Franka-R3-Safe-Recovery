# Literature evidence for the 10-minute safe-recovery talk

Checked 2026-09-15. Primary papers, author institutions, and original project pages only. This is a selected research context, not an exhaustive systematic review or a novelty assessment. Literature does not validate our local simulator's force magnitudes.

## Recommended six references for the talk

Use **Goli 2024, Hogan 1985, Posa 2014, Ames 2017, IndustReal 2023, Whitney 1982**. Factory is an optional seventh reference for simulator context. Raibert 1981 and AutoMate 2024 are optional alternatives below.

### [1] Whitney — mechanics foundation

- **D. E. Whitney (1982). “Quasi-Static Assembly of Compliantly Supported Rigid Parts.”** Journal of Dynamic Systems, Measurement, and Control, 104(1), 65–77. DOI: [10.1115/1.3149634](https://doi.org/10.1115/1.3149634).
- Primary original-paper mirror: [USPTO archive](https://ptacts.uspto.gov/ptacts/public-informations/petitions/1460618/download-documents?artifactId=NnJY0FjDRp2_R2aq9NuY_y-CuHlaMfhnqlMU04PeqhBTWTki5KMeBcc). Indexed first-page text inspected; direct publisher fetch returned 403.
- Supported contribution: Geometric and force-equilibrium conditions for rigid-part mating, with remote-center-compliance analysis and experimentally checked insertion-force models.
- **Slide wording (11 words): “Contact geometry, friction and compliance determine whether rigid-part assembly proceeds smoothly.”**
- Relevance: Motivate depth, clearance, angle and compliance as coupled factors.
- Limit: Does not model our plastic-hole deformation or establish our 4 N threshold; insertion theory must not automatically become an extraction guarantee.

### [2] Goli et al. — directly relevant disassembly research

- **Farzaneh Goli, Ali Aflakian, Mo Qu, Yue Zang, Mozafar Saadat, Duc Truong Pham, Yongjing Wang (2024). “Characterizing the mechanics of rectangular peg–hole disassembly and the effect of the active compliance centre on the extraction force.”** Royal Society Open Science, 11(11), 240956. DOI: [10.1098/rsos.240956](https://doi.org/10.1098/rsos.240956).
- Primary full text: [University of Birmingham, publisher version](https://pure-oai.bham.ac.uk/ws/portalfiles/portal/249539258/rsos.240956.pdf).
- Supported contribution: Combines geometric/quasistatic analysis and robot experiments to relate rectangular-peg extraction and jamming to active-compliance-center placement.
- **Slide wording (10 words): “Disassembly studies link extraction forces to contact states and compliance.”**
- Relevance: Strong precedent for studying withdrawal, depth and compliance explicitly.
- Limit: Rectangular rigid pegs, vertical extraction and specified compliance assumptions differ from our cylindrical setup. Does not verify our budget-conditioned labels or brittle-grip interpretation.

### [3] Hogan — interaction control

- **Neville Hogan (1985). “Impedance Control: An Approach to Manipulation: Part I—Theory.”** Journal of Dynamic Systems, Measurement, and Control, 107(1), 1–7. DOI: [10.1115/1.3140702](https://doi.org/10.1115/1.3140702).
- Primary full text: [MIT Newman Laboratory](https://newmanlab.mit.edu/wp-content/uploads/2017/09/1985-impedance-control-an-approach-to-manipulation-part-I-theory.pdf). Indexed original-paper first-page text inspected; direct fetch unreliable.
- Supported contribution: Formulates manipulation as controlled dynamic interaction with the environment, motivating impedance rather than position/force objectives alone.
- **Slide wording (9 words): “Shape interaction dynamics through virtual stiffness, damping and inertia.”**
- Relevance: Proposed Cartesian impedance or admittance recovery controller; tune compliance during reorientation and withdrawal.
- Limit: Impedance control alone does not guarantee a strict force ceiling or preserve recoverability under unknown contact.

### [4] Posa et al. — motion planning through contact

- **Michael Posa, Cecilia Cantu, Russ Tedrake (2014). “A direct method for trajectory optimization of rigid bodies through contact.”** International Journal of Robotics Research, 33(1), 69–81. DOI: [10.1177/0278364913506757](https://doi.org/10.1177/0278364913506757).
- Primary sources: [Publisher abstract](https://journals.sagepub.com/doi/abs/10.1177/0278364913506757); [MIT author manuscript](https://groups.csail.mit.edu/robotics-center/public_papers/Posa13.pdf). Online publication 2013, journal issue 2014; cite 2014.
- Supported contribution: Contact-implicit trajectory optimization jointly resolves trajectories and contact forces without a prescribed contact-mode sequence.
- **Slide wording (10 words): “Optimize motions and contact forces without fixing contact modes beforehand.”**
- Relevance: Proposed optimizer over retreat, translation and rotation, with load budgets as constraints.
- Limit: Nonconvex local optimization with a contact model; no automatic global recovery or sim-to-real guarantee. Do not call it the first such method; a corrigendum acknowledges prior related formulations.

### [5] Ames et al. — safety-constrained control

- **Aaron D. Ames, Xiangru Xu, Jessy W. Grizzle, Paulo Tabuada (2017). “Control Barrier Function Based Quadratic Programs for Safety Critical Systems.”** IEEE Transactions on Automatic Control, 62(8), 3861–3876. DOI: [10.1109/TAC.2016.2638961](https://doi.org/10.1109/TAC.2016.2638961).
- Primary text: [arXiv:1609.06408](https://arxiv.org/abs/1609.06408); [author-hosted journal PDF](https://xu.me.wisc.edu/wp-content/uploads/sites/1196/2019/08/Control-barrier-function-based-quadratic-programs-for-safety-critical-systems.pdf). Preprint 2016, journal 2017.
- Supported contribution: Combines forward-invariance safety constraints with performance objectives in real-time quadratic-program controllers.
- **Slide wording (9 words): “Filter nominal controls through model-based constraints that preserve safety.”**
- Relevance: Candidate safety filter for a later controller with validated force dynamics and margins.
- Limit: Our sample-wise threshold stop is not a CBF. Nonsmooth contact, sensing delay, model error, and feasibility must be addressed before claiming force-limit guarantees.

### [6] IndustReal — assembly sim-to-real

- **Bingjie Tang, Michael A. Lin, Iretiayo Akinola, Ankur Handa, Gaurav S. Sukhatme, Fabio Ramos, Dieter Fox, Yashraj Narang (2023). “IndustReal: Transferring Contact-Rich Assembly Tasks from Simulation to Reality.”** Robotics: Science and Systems XIX. [arXiv:2305.17110](https://arxiv.org/abs/2305.17110).
- Primary project: [NVIDIA Research](https://research.nvidia.com/publication/2023-05_industreal-transferring-contact-rich-assembly-tasks-simulation-reality).
- Supported contribution: Demonstrates assembly-policy transfer using simulation-aware updates, geometric rewards, curricula and a deployment action integrator.
- **Slide wording (9 words): “Assembly transfer requires simulation-aware training and deliberate deployment design.”**
- Relevance: Curriculum, randomized parameters, calibration and deployment evaluation are useful later-stage techniques.
- Limit: Its real-world success does not calibrate our contact forces, establish a brittle-part limit, or demonstrate our recovery policy.

### [7] Factory — optional simulation context

- **Yashraj Narang, Kier Storey, Iretiayo Akinola, Miles Macklin, Philipp Reist, Lukasz Wawrzyniak, Yunrong Guo, Adam Moravanszky, Gavriel State, Michelle Lu, Ankur Handa, Dieter Fox (2022). “Factory: Fast Contact for Robotic Assembly.”** Robotics: Science and Systems XVIII. [arXiv:2205.03532](https://arxiv.org/abs/2205.03532).
- Primary project: [NVIDIA Research](https://research.nvidia.com/publication/2022-05_factory-fast-contact-robotic-assembly).
- Supported contribution: Fast contact simulation methods, assembly models/environments and controllers for scalable robotic assembly research.
- **Slide wording (9 words): “Fast contact simulation enables systematic, repeatable robotic assembly experiments.”**
- Limit: Platform capability is not physical validation of our timestep, material parameters or peak forces.

## Optional alternatives

### [8] Wabersich and Zeilinger — predictive safety filtering under uncertainty

- **Kim Peter Wabersich and Melanie N. Zeilinger (2021). “A predictive safety filter for learning-based control of constrained nonlinear dynamical systems.”** Automatica, 129, 109597. DOI: [10.1016/j.automatica.2021.109597](https://doi.org/10.1016/j.automatica.2021.109597).
- Primary sources: [publisher article](https://www.sciencedirect.com/science/article/pii/S0005109821001175), [arXiv:1812.05506](https://arxiv.org/abs/1812.05506). Cite the 2021 journal version; the original preprint dates to 2018.
- Supported contribution: Predictively accepts or modifies proposed controls using an MPC formulation with a data-driven dynamics model and state/input-dependent uncertainty.
- **Slide wording (12 words): “Predict constraint violations and modify candidate controls using models with quantified uncertainty.”**
- Relevance: Stronger fit than a generic CBF reference for the proposed finite-horizon recovery planner and predictive safety filter.
- Limit: Guarantees depend on model/uncertainty assumptions, a suitable safe backup/terminal construction, and optimization feasibility. Neither implementation nor guarantees transfer automatically to our nonsmooth contact system. This method is proposed future work here.

For a compact six-reference slide list focused on the final proposed architecture, use Goli 2024, Hogan 1985, Posa 2014, Wabersich/Zeilinger 2021, IndustReal 2023, Whitney 1982; retain Ames in the appendix as an alternative.

- **M. H. Raibert and J. J. Craig (1981). “Hybrid Position/Force Control of Manipulators.”** Journal of Dynamic Systems, Measurement, and Control, 103(2), 126–133. DOI [10.1115/1.3139652](https://doi.org/10.1115/1.3139652). [Original paper hosted by MIT](https://fab.cba.mit.edu/classes/865.15/classes/measurement/hybrid-position-force.pdf). Contribution: simultaneously specify position and force behavior in task-related coordinates. Slide: “Assign motion and force objectives to selected task-space directions.” Does not itself guarantee force-limited recovery.
- **Bingjie Tang, Iretiayo Akinola, Jie Xu, Bowen Wen, Ankur Handa, Karl Van Wyk, Dieter Fox, Gaurav S. Sukhatme, Fabio Ramos, Yashraj Narang (2024). “AutoMate: Specialist and Generalist Assembly Policies over Diverse Geometries.”** RSS 2024. [NVIDIA primary project](https://research.nvidia.com/publication/2024-07_automate-specialist-and-generalist-assembly-policies-over-diverse-geometries), [arXiv:2407.08028](https://arxiv.org/abs/2407.08028). Contribution: assembly learning across diverse geometries with real-world transfer. Slide: “Broaden evaluation across geometries, beyond a single tuned assembly.” Does not validate our finite-budget recovery classifier.

## Suggested one-slide literature map

| Foundation | Established capability | What this project will test |
|---|---|---|
| Contact mechanics [1,2] | Geometry and compliance affect mating and extraction | Predict when the current state becomes difficult to exit |
| Interaction control [3] | Shape compliant robot–environment interaction | Recover with bounded measured task loads |
| Contact-aware planning [4] | Optimize motion through changing contacts | Choose retreat and reorientation before an unsafe state |
| Safety filters [5] | Enforce model-based state constraints | Predict force growth; account for sampling and uncertainty |
| Assembly sim-to-real [6] | Transfer carefully engineered assembly policies | Calibrate grip/load limits and validate on metal–plastic parts |

## Positioning language for this project

**Use:** “We investigate budget-conditioned recoverability using matched insertion histories and alternative recovery paths.”

**Use:** “Current evidence is a simulation proof of concept; robust control and hardware validation are next.”

**Avoid:** “Existing work ignores recovery”; “first safe disassembly method”; “4 N is a verified fracture limit”; “threshold stopping guarantees continuous-time force safety.”

## Course-aligned proposed architecture (clearly label as future work)

State estimation → contact-aware local planner → compliant controller → predictive safety filter → robot/contact dynamics → wrench/pose feedback.

- **Kinematics:** Cartesian pose errors, Jacobian-based differential motion and joint constraints.
- **Planning:** local translation/rotation/withdrawal primitives first; trajectory optimization or sampling-based MPC later.
- **Control:** stiffness/damping adaptation; reduced speed near load margins; hysteresis and dwell times for mode switches.
- **Safety:** predict peak load and retain a validated margin; current reactive sample-wise stop is a baseline.
- **Evaluation:** untouched test geometry/parameter groups; success, peak/100 ms load, overshoot, clearance, grasp retention and numerical sensitivity.

Candidate research objective: choose a recovery trajectory that reaches clearance while respecting force/torque limits and preserving grasp. A learned recoverability estimate can rank candidate actions; it must not be presented as a safety certificate before validation.

## Review of the proposed 12-slide / 600-second structure

The timing sums to exactly 600 seconds. The narrative is coherent and there is no need for an extra main slide. Keep literature to one visual map and put full references in an untimed appendix.

**Must be explicit on the main slides:**

1. **Problem/formulation (slides 2/4):** The present budget constrains the simulated wrist-force norm. Limited frictional grip and fragile workpieces motivate it; actual grip capacity or fracture has not been calibrated. Distinguish a policy-specific failure from physical unextractability: failing two tested policies does not prove that no feasible recovery exists.
2. **Main pair (slide 6):** The two policies start from matched reference states. Realignment is an alternative taken before the direct-path exceedance, not a rescue tested after the already-unsafe endpoint. Label the direct 4.54 N value “first exceedance; censored,” and 3.75 N “complete recovery peak.”
3. **Sampling caveat (slides 5/12):** Include one visible sentence: “Peak-based evidence at 240 Hz; robustness to contact numerics remains unverified.” A sampled stop observes an overshoot; it is not a physical force clamp. Do not bury this in references.
4. **Depth/angle (slides 8/9):** Describe controlled comparisons, not a globally monotonic law. The 3°–6° commands were not attained under the budget; changing angle at fixed ramp duration also changes commanded angular speed.
5. **Labels (slide 10):** Keep recovery-precondition failure, observed policy exceedance, successful clearance, and untested/unknown separate. Treat truncated trajectories as censored and split shared histories together in future train/test sets.
6. **Future architecture (slide 11):** Draw the level at which the safety filter acts. A practical proposal is local MPC → filtered Cartesian reference → impedance controller → robot, with a predictive model of that closed-loop interaction. Avoid implying an unmodeled wrench threshold can simply become a torque-level CBF. Mark all predictive filtering as “proposed.”
7. **Milestones (slide 12):** First reproduce across timestep/solver/seeds and measure sensor/grip limits; then develop predictive recovery; finally test hardware transfer. A validated backup region and uncertainty model are prerequisites for a guarantee, not outputs already established.

**Recommended closing sentence:** “The simulation supports strategy-dependent recovery under a specified load budget; robust prevention and hardware validation are the next milestones.”
