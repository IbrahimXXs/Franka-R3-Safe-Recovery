"""Create a 12-slide English research talk plus four untimed appendix pages.

Charts use the archived experiment data. Scene images replay recorded poses.
The PDF keeps chart geometry and diagram/text objects as vector content.
"""
from pathlib import Path
import hashlib
import json
import math
from html import escape

from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader, PdfWriter, Transformation

BASE = Path(__file__).resolve().parent
ROOT = next(p for p in BASE.parents if (p/'research/forge_budget.py').is_file())
OUT = ROOT/'output/pdf'
OUT.mkdir(parents=True, exist_ok=True)
FIG = BASE/'figures'
SCENE = BASE/'scene'
W, H = 960., 540.
NAVY = HexColor('#17324D')
TEAL = HexColor('#008D84')
RED = HexColor('#C74349')
AMBER = HexColor('#AF7426')
MUTED = HexColor('#566879')
LINE = HexColor('#CED8E1')
PALE = HexColor('#F0F5F7')
GREEN = HexColor('#E5F2EE')

FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Sans', 'DejaVuSans.ttf'), ('Sans-Bold', 'DejaVuSans-Bold.ttf'),
                   ('Sans-Oblique', 'DejaVuSans.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR/file)))
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='Sans-Bold', italic='Sans-Oblique')

PAGES = []
PLACEMENTS = []
TIMES = [20, 55, 55, 45, 45, 65, 45, 60, 70, 65, 50, 25]
assert sum(TIMES) == 600
BASE_PDF = BASE/'talk_base.pdf'
C = canvas.Canvas(str(BASE_PDF), pagesize=(W,H), pageCompression=1)
C.setTitle('Preventing Insertion-Induced Jamming')
C.setAuthor('Franka Safe Recovery Research Project')
C.setSubject('Motion planning and control: simulation proof of concept and research plan')


def text(x, y, value, size=18, color=NAVY, bold=False):
    """Top-left coordinates, baseline at y + font size."""
    C.setFont('Sans-Bold' if bold else 'Sans', size)
    C.setFillColor(color)
    C.drawString(x, H-y-size, value)


def para(x, y, value, width, size=18, color=NAVY, leading=None, bold=False):
    style = ParagraphStyle('p', fontName='Sans-Bold' if bold else 'Sans', fontSize=size,
                           leading=leading or size*1.32, textColor=color,
                           spaceBefore=0, spaceAfter=0)
    p = Paragraph(value, style)
    _, height = p.wrap(width, H)
    if y+height > H-25:
        raise ValueError(f'Paragraph overflows page {len(PAGES)}: {value[:60]}')
    p.drawOn(C, x, H-y-height)
    return height


def line(x1,y1,x2,y2,color=LINE,width=1):
    C.setStrokeColor(color); C.setLineWidth(width)
    C.line(x1,H-y1,x2,H-y2)


def rect(x,y,w,h,fill=PALE,stroke=None,linewidth=1):
    C.setFillColor(fill)
    C.setStrokeColor(stroke or fill); C.setLineWidth(linewidth)
    C.rect(x,H-y-h,w,h,fill=1,stroke=bool(stroke))


def arrow(x1,y1,x2,y2,color=MUTED,width=1.6,head=7):
    line(x1,y1,x2,y2,color,width)
    angle=math.atan2(y2-y1,x2-x1)
    p=C.beginPath();p.moveTo(x2,H-y2)
    for a in (angle+2.6,angle-2.6):
        p.lineTo(x2+head*math.cos(a),H-(y2+head*math.sin(a)))
    p.close();C.setFillColor(color);C.drawPath(p,fill=1,stroke=0)


def node(x,y,w,h,title,subtitle='',color=NAVY):
    rect(x,y,w,h,white,color,1.2)
    para(x+12,y+11,title,w-24,17,color,bold=True)
    if subtitle:para(x+12,y+38,subtitle,w-24,13.5,MUTED)


def image(path,x,y,w,h):
    reader=ImageReader(str(path));iw,ih=reader.getSize()
    scale=min(w/iw,h/ih);dw,dh=iw*scale,ih*scale
    C.drawImage(reader,x+(w-dw)/2,H-y-(h+dh)/2,dw,dh,mask='auto')


def chart(name,x,y,w,h):
    path=FIG/(name+'.pdf')
    r=PdfReader(path);box=r.pages[0].mediabox
    iw,ih=float(box.width),float(box.height)
    scale=min(w/iw,h/ih);dw,dh=iw*scale,ih*scale
    PLACEMENTS.append(dict(page=len(PAGES)-1,path=str(path),scale=scale,
                           x=x+(w-dw)/2,y=H-y-(h+dh)/2))


def footer(source='', page=None):
    line(44,508,916,508)
    if source:text(44,516,source,9.4,MUTED)
    text(881,514,page or f'{len(PAGES):02d} / 12',10,MUTED)


def start(title,section,notes='',appendix=False):
    if PAGES:C.showPage()
    PAGES.append(dict(number=len(PAGES)+1,title=title,section=section,
                      seconds=0 if appendix else TIMES[len(PAGES)],speaker_notes=notes))
    rect(0,0,W,H,white)
    text(44,22,section.upper(),10.5,TEAL,bold=True)
    text(44,43,title,31,NAVY,bold=True)


def takeaway(value,y=451,color=TEAL):
    line(44,y,916,y,color,1.7)
    para(44,y+13,value,872,18,color,bold=True)


# 01: 25 seconds
start('Preventing insertion-induced jamming','Motion Planning and Control',
      'The primary objective is an insertion planning and control policy that avoids insertion-induced jamming. The secondary objective, if progress becomes blocked, is to adjust the pose and restore withdrawability within the available operation-force budget. Existing experiments establish a useful adverse scenario and preliminary recovery feasibility; they do not validate a preventive insertion policy.')
rect(0,0,W,H,white)
text(44,38,'MOTION PLANNING AND CONTROL',12,TEAL,True)
para(44,112,'Preventing<br/>insertion-induced<br/>jamming',369,36,NAVY,leading=44,bold=True)
para(46,282,'First avoid risky insertion.<br/>Then restore a force-limited exit.',370,19,MUTED)
image(SCENE/'bench_reference.png',426,92,500,332)
line(44,388,351,388,TEAL,2)
text(44,414,'Research progress and technical roadmap',15,MUTED)
text(44,441,'September 2026',13,MUTED)
footer('Robot image: recorded-state replay in Isaac Sim. Visualization only.')


# 02: Scenario and contact mechanics
start('A tight insertion can create a difficult exit','Physical scenario',
      'The intended hardware is a metal peg in a tight plastic socket. Pose error and deeper engagement can create restrictive edge or wall contacts. Normal reactions and friction may oppose insertion and extraction; a straight pull may preserve an unfavorable contact geometry. This is a qualitative rigid-contact explanation, not a universal monotonic law. Plastic deformation could create additional obstacles in real hardware but is absent from the current rigid-body simulation. The schematic exaggerates clearance and marks possible contacts, not measured locations.')
# Explanatory cutaway; contact markers are schematic.
rect(117,252,90,147,HexColor('#DCE5EB'));rect(246,252,90,147,HexColor('#DCE5EB'))
rect(117,381,219,18,HexColor('#DCE5EB'))
C.saveState();C.translate(226,H-320);C.rotate(-5)
C.setFillColor(HexColor('#7297AB'));C.rect(-14,-45,28,190,stroke=0,fill=1);C.restoreState()
rect(157,165,46,46,NAVY);rect(250,165,46,46,NAVY)
arrow(226,126,226,155,TEAL,2);text(250,126,'insertion',14,TEAL)
C.setFillColor(RED)
for x,y in [(247,255),(208,363)]:C.circle(x,H-y,5,stroke=0,fill=1)
arrow(307,255,260,255,RED,2);arrow(151,363,196,363,RED,2)
para(107,420,'Metal peg / tight plastic socket<br/>Possible opposing contacts',274,14,MUTED)
rows=[('01','Alignment error','Tilt and deep engagement can create<br/>opposing edge or wall contacts.'),
      ('02','Restricted motion','Contact reactions and friction can resist<br/>both insertion and withdrawal.'),
      ('03','Change the contact state','Lateral or angular correction may be<br/>needed before a low-force exit is possible.')]
for i,(num,title,body) in enumerate(rows):
 y=125+i*112
 text(425,y,num,18,TEAL,True);text(466,y,title,21,NAVY,True)
 para(466,y+37,body,443,17,MUTED)
footer('Metal peg / plastic socket is the intended scenario. Schematic contacts only. Current rigid simulation excludes plastic damage. [1,2]')

# 03: Why the force constraint exists
start('Why pulling harder is not a general solution','Task-specific load limits',
      'A friction grip can transmit only a finite pulling load. Increasing pull can require more squeeze, while gripper capacity and allowable contact pressure limit squeeze. The metal peg need not be fragile: the plastic socket, finish or fixture may set the damage limit. Strong extraction can also elastically deflect the robot, gripper or fixture; abrupt release can convert stored strain energy into motion. These mechanisms motivate a task-calibrated limit rather than the arm maximum. The ideal friction bound omits gravity, acceleration and moments. Grip squeeze, axial pull and raw wrist-force norm differ. No damage or release-risk model is validated by current experiments.')
cols=[(44,'1  Grasp capacity','Pull requires fingertip friction.','More pull requires more squeeze.','Slip or local damage limits the grip.'),
      (343,'2  Part integrity','Tilt concentrates contact loading.','Friction and bending load the socket.','Plastic, surfaces or fixtures may fail.'),
      (642,'3  Controlled release','High load deflects the assembly.','Elastic energy can accumulate.','Sudden release can cause rapid motion.')]
for x,title,a,b,c in cols:
 text(x,118,title,20,NAVY,True)
 para(x,165,a,273,17,MUTED)
 arrow(x+125,218,x+125,239,TEAL,1.6)
 para(x,252,b,273,17,MUTED)
 arrow(x+125,306,x+125,327,TEAL,1.6)
 para(x,342,c,273,17,RED)
line(44,405,916,405)
para(44,419,'Ideal friction grip: F<sub>pull</sub> ≤ μ<sub>g</sub>(N<sub>L</sub> + N<sub>R</sub>)',440,20,TEAL)
para(44,460,'N<sub>L</sub>, N<sub>R</sub>: finger normal forces. μ<sub>g</sub>: grip friction.',452,13,MUTED)
para(518,418,'Current proxy: wrist norm ≤ B, torque ≤ 1 N·m.<br/>3 / 4 / 5 N are exploratory budgets, not calibrated limits.',396,14.7,MUTED)
footer('Physical motivation, not validated damage/release modes. Calibrate grasp, part and motion limits for the task. [2,9,10]')
# 04: 45 seconds
start('Research context','Selected literature',
      'Assembly and extraction mechanics connect geometry, contact and compliance. Our primary question is how an insertion policy avoids risky contact states before a jam develops. Force-limited recovery is the secondary objective. Contact-aware optimization, impedance control and sim-to-real assembly provide candidate tools, not evidence that our measured forces are physically calibrated or that prevention has been validated.')
rows=[('Contact and extraction','Geometry, friction and compliance shape mating forces.','Whitney 1982 [1]\nGoli et al. 2024 [2]'),
      ('Interaction control','Virtual stiffness and damping shape contact response.','Hogan 1985 [3]'),
      ('Planning through contact','Trajectory optimization can include changing contact modes.','Posa et al. 2014 [4]'),
      ('Safety and transfer','Predictive filtering and calibrated deployment address model risk.','Wabersich 2021 [8]\nIndustReal 2023 [6]')]
for i,(a,b,r) in enumerate(rows):
    y=116+i*76
    text(48,y,a,18,NAVY,True)
    para(318,y,b,360,16.3,MUTED)
    para(711,y,r.replace('\n','<br/>'),204,13.4,TEAL)
    line(48,y+61,913,y+61)
takeaway('First avoid risky insertion. Then restore an exit within the force budget.',445)
footer('Selected primary literature, not an exhaustive novelty claim. Full references in the appendix.')

# 05: 50 seconds
start('Current testbed and recovery probes','Testbed and protocol',
      'Show the actual recorded states in the unchanged simulation scene. The reference reaches a depth gate before applying tilt for one second. Then STOP holds the attained pose, and a chosen policy retreats directly or recenters and realigns. Each policy runs in an independent process; the complete recorded reference prefix is compared offline. The budget starts at recorded reference time zero and excludes preparation.')
texts=[('Reference state','18.228 mm depth, 1.439° tilt','closeup_reference.png'),
       ('Recentered and realigned','18.076 mm depth, 0.170° tilt','closeup_realigned.png'),
       ('Clearance','-3.009 mm depth, 0.063° tilt','closeup_clear.png')]
for i,(title,detail,img) in enumerate(texts):
    x=44+i*294
    image(SCENE/img,x,113,284,174)
    text(x,295,title,16,NAVY,True)
    text(x,323,detail,12.6,MUTED)
labels=[('INSERT','depth gate'),('TILT + HOLD','1 s + 1 s'),('STOP','0.25 s'),('RECOVER','direct or realign'),('CLEAR','end condition')]
for i,(a,b) in enumerate(labels):
    x=44+i*177
    node(x,373,158,69,a,b,TEAL if i in (3,4) else NAVY)
    if i<4:arrow(x+158,407,x+176,407,head=5)
para(44,460,'Rigid bodies, 0.2 mm radial gap, 25 mm blind hole. Physics and task control: 240 Hz.',868,14.5,MUTED)
footer('Recorded-state replays, same camera. Sampled stop permits overshoot and excludes grasp preparation. [D1,7]')

# 06: 65 seconds
start('Evidence: the exit depends on the motion','Preliminary evidence',
      'Both policies start at the same fully matched reference state. The common full-reference peak, including tilt and hold, is 3.56 N. Direct withdrawal crosses 4 N at 0.721 seconds, while recentering and realignment completes with a 3.75 N full-recovery peak and 1.15 N withdrawal-only peak. The direct record is censored at the first violation. This is an alternative selected at the reference state, not a rescue started after the violation. Different horizontal time scales are explicit.')
para(46,95,'18 mm target depth · μ = 1 · 1.5° command tilt · 4 N budget',865,17,MUTED)
chart('paired_recovery_force',41,132,878,291)
para(46,432,'Matched reference: 2,811 samples per policy · reference peak 3.56 N.',863,17,NAVY,bold=True)
para(46,464,'Direct path stops at first exceedance. This pair motivates prevention; it does not validate it.',868,14.6,MUTED)
footer('Raw traces from independent simulator processes. Equality with the budget is allowed; strictly greater triggers stopping. [D1]')

# 07: 45 seconds
start('The budget changes feasibility','Task-dependent labels',
      'For the same planned physical path, 3 N is too tight even for the reference hold. At 4 N the two recovery strategies separate. At 5 N both complete. The 4 and 5 N direct paths share 174 identical recorded recovery samples up to the 4 N stopping frame. Higher-budget data never fills the missing future of the lower-budget record. Budget must be a model input.')
chart('budget_comparison',48,99,865,322)
takeaway('Recoverability depends on state, candidate policy and the task budget.',439)
footer('The 4 N direct peak is censored. Shared 4/5 N recovery prefix: 174 identical samples, excluding clocks. [D1]')


# 08: Proposed modeling and dataset
start('Learn when insertion becomes costly to undo','Proposed method 1: risk prediction',
      'Use observable insertion history to predict near-term load and whether a tested exit motion remains feasible. Candidate inputs are actual depth and tilt, commanded versus actual progress, wrist force and torque trends, and budget margin. Simulator contact decomposition is privileged diagnostic data, not assumed hardware input. During new simulation collection, replay matched insertion prefixes to selected checkpoints, then branch independent recovery probes. Label persistent restricted progress and load growth as candidate risk indicators; label policy-specific exit completion and full-path peak separately. Censored peaks are lower bounds, not completed-path targets. Start with interpretable rules or a small classifier and use a temporal model or ensemble only with enough data. None is trained yet.')
node(44,114,255,91,'Observable history','depth, tilt, progress, wrench<br/>next action and load margin')
node(345,114,245,91,'Checkpoint probes','replay matched insertion<br/>test candidate exits offline')
node(636,114,280,91,'Prediction','next-step load and stall risk<br/>exit feasibility for each policy')
arrow(299,160,344,160);arrow(590,160,635,160)
text(44,243,'Why this helps',20,TEAL,True)
para(259,239,'A state may still permit insertion while making withdrawal expensive.<br/>Predict that cost before committing to the next insertion segment.',655,17,NAVY)
text(44,323,'Start simple',19,NAVY,True)
para(259,319,'Rules or a small classifier → temporal model / ensemble<br/>only after collecting enough matched histories.',655,17,MUTED)
para(44,402,'Keep censored and untested outcomes separate. Split data by shared physical path.',872,16.5,MUTED)
takeaway('Primary output: an early warning that changes the next insertion action.',447)
footer('Proposed dataset and models. Existing logs support scenario selection; a jam-prevention predictor is not yet validated. [D1]')

# 09: Primary planning and control method
start('Prevent jamming before advancing deeper','Proposed method 2: insertion planning',
      'Start with a risk-triggered finite-state baseline, then evaluate local model predictive control. At every cycle propose short advance, slow, recenter and rotate actions. Predict insertion progress, next-step wrist load and the cost of a tested exit. Reject motions that consume the available force margin or predicted exit feasibility, execute only the first short admissible segment and replan. Smaller advance near load growth limits further penetration; lateral and rotational compliance may help align the peg rather than forcing pose error against the walls. Compliance alone cannot guarantee a force ceiling. The model predicts the closed-loop robot/contact response, with identified uncertainty margins. Compare progress and aborts so a controller that never inserts cannot appear successful.')
node(44,114,190,82,'Propose motions','advance / slow / align')
node(274,114,198,82,'Predict outcomes','progress, load, exit cost')
node(512,114,180,82,'Filter actions','budget and uncertainty')
node(732,114,184,82,'Act and replan','one short segment')
for a,b in [(234,273),(472,511),(692,731)]:arrow(a,155,b,155)
para(44,224,'Objective: insertion progress − risk penalty − motion effort',870,22,TEAL)
rows=[('PLAN  [4,8]','Local MPC selects depth, offset, tilt and speed while retaining a predicted exit.'),
      ('CONTROL  [3]','Use Jacobian-based Cartesian control; tune lateral/rotational stiffness and damping.'),
      ('FILTER  [8]','Modify or reject a reference if predicted load exceeds B minus an uncertainty margin.')]
for i,(head,body) in enumerate(rows):
 y=291+i*55;text(44,y,head,17,NAVY,True);para(232,y,body,682,16.4,MUTED)
para(44,466,'Rules → local model predictive control (MPC). Compliance alone does not enforce the force limit.',870,14.6,MUTED)
footer('Proposed closed-loop policy and safety filter. Predict robot + contact response and validate model error before relying on constraints. [3,4,8]')

# 10: Recovery method
start('Restore withdrawability under the same limit','Proposed method 3: constrained recovery',
      'When progress is persistently blocked, stop advancing and assess the attained state. Search small lateral and angular adjustments followed by withdrawal, and compare maximum load across the complete adjustment-and-exit path. The depth study shows that realignment is not always cheaper, so it must be evaluated rather than always applied. A predictive safety filter can modify or reject references before a predicted violation; current sampled stopping only reacts after observing one. Execute a short segment then reassess. A failed library search means no validated candidate in that library, not physical irrecoverability. The existing 4 N pair starts from a matched reference before the straight-path violation; restoration from post-violation blocked states still needs testing.')
node(44,114,191,80,'Assess blockage','hold the attained pose')
node(277,114,191,80,'Adjust contact','small offset / tilt')
node(510,114,191,80,'Probe exit','bounded short motion')
node(743,114,173,80,'Reassess','clear or replan')
for a,b in [(235,276),(468,509),(701,742)]:arrow(a,154,b,154)
text(44,232,'Search the entire recovery path',20,NAVY,True)
para(44,274,'Choose the candidate with the lowest predicted peak load<br/>that reaches clearance and retains the grasp.',864,20,TEAL)
text(44,347,'How it works',18,NAVY,True)
para(240,343,'Change contact geometry before the full axial pull.<br/>Include adjustment cost, uncertainty and stopping response.',674,17,MUTED)
para(44,419,'Begin with a motion library. Add local MPC and predictive filtering after model validation.',872,16.3,MUTED)
para(44,467,'No admissible candidate → no validated action in the tested library; reassess the task.',872,14.6,MUTED)
footer('Existing 4 N evidence is a matched-reference comparison, not a rescue after the recorded violation. See depth evidence in Appendix A. [2,4,8]')

# 11: Validation and sim-to-real
start('Validate the mechanism, then the policy','Evaluation and transfer',
      'Before learning from force peaks, independently vary physics rate, controller rate, solver settings and movement speed. Then compare ordinary insertion with a risk-aware policy under matched disturbances and held-out depth, clearance and friction groups. Measure insertion completion, peak load, premature aborts and subsequent bounded-force exit, so stopping early cannot win by itself. Recovery comparisons use matched blocked states and full-path peak, overshoot and grasp retention. On hardware first measure grasp friction/capacity and allowable socket/fixture loads, identify stiffness/friction uncertainty, then randomize identified ranges for transfer. CBF filtering is a later option only when contact dynamics, feasible backup actions and invariance assumptions can be defended.')
rows=[('01','Trust the measurements','Separate physics and control rates.<br/>Check solver, speed and load-signal sensitivity.'),
      ('02','Test prevention','Baseline vs risk-aware insertion under matched disturbances.<br/>Report completion, peak load, aborts and later exit success.'),
      ('03','Test recovery','Matched blocked states, same force budget.<br/>Report completion, peak load, overshoot and grasp retention.'),
      ('04','Calibrate and transfer','Measure grip and part/fixture limits.<br/>Randomize identified uncertainty before hardware tests. [6]')]
for i,(num,title,body) in enumerate(rows):
 y=118+i*78;text(44,y,num,22,TEAL,True);text(98,y,title,19,NAVY,True)
 para(384,y,body,532,15.6,MUTED)
 if i<3:line(44,y+65,916,y+65)
para(44,458,'Control barrier functions (CBFs) [5]: a later option after validating dynamics and backup actions.',872,14.8,MUTED)
footer('Current evidence is sampled rigid-body simulation. Numerical sensitivity, calibrated task limits and hardware validity remain open. [D1,5,6]')

# 12: Conclusion
start('Prevent first. Recover within limits if needed.','Research conclusion',
      'The central objective is to learn and control insertion so that restrictive contact states are avoided. Recovery is the second objective: if progress becomes blocked, restore withdrawability without exceeding the available operation force. Existing matched trials give an adverse scenario and preliminary recovery feasibility. They do not demonstrate preventive insertion control. The next study links insertion history to future exit cost, then compares a risk-aware insertion policy against the current baseline. Robustness and hardware calibration remain essential.')
text(44,120,'What we have',21,TEAL,True)
para(282,115,'A reproducible adverse scenario:<br/>direct exit exceeds 4 N; a different motion clears.',632,21,NAVY,bold=True)
text(44,229,'Primary research',21,TEAL,True)
para(282,223,'Predict risk from insertion history.<br/>Choose motions that avoid jam-prone states.',632,21,NAVY)
text(44,337,'Secondary research',20,NAVY,True)
para(282,331,'Restore a feasible exit when progress is blocked.<br/>Constrain both adjustment and withdrawal.',632,20,MUTED)
takeaway('Recovery scenario established. Preventive insertion control is the next test.',451)
footer('All proposed predictors, MPC policies and predictive safety filters require new implementation and validation.')
# 08: 50 seconds
start('Embedding depth changes the recovery cost','Appendix A: parameter evidence',
      'At the shallower 12 mm target the direct path completes at roughly 0.32 N. The 18 mm direct path reaches the 4.54 N violation. Actual reference tilts differ slightly, so this is a descriptive controlled depth comparison rather than an identical-state force experiment. Realignment can itself add cost: at 12 mm its complete peak exceeds direct withdrawal. The optimizer must evaluate the whole recovery, not only the final pull phase.',True)
chart('depth_comparison',38,105,559,307)
text(642,117,'18 mm direct path',19,NAVY,True)
text(642,163,'1.105 mm',31,MUTED,True)
para(642,207,'Commanded withdrawal<br/>at the stopping frame',265,16,MUTED)
text(642,280,'0.137 mm',31,RED,True)
para(642,324,'Measured withdrawal<br/>at the same frame',265,16,MUTED)
takeaway('Recovery cost can inform insertion risk. Prevention needs closed-loop tests.',442)
footer('Actual reference tilts: 12 mm case 1.524°; 18 mm case 1.439°. Whole-recovery peaks; 18 mm direct is censored. [D1]','A1')

# A1: study coverage; outside the ten-minute main talk
start('Budget-study evidence coverage','Appendix B',
      'Reference for questions. Do not pool deterministic reruns as independent statistical trials. The original budget matrix executed 13 branches. Preserve planned but untested alternatives.',True)
chart('condition_outcomes',41,104,877,288)
para(48,411,'[D1] Budget study: 8 conditions, 13 executed branches, 3 untested.',862,17,NAVY)
para(48,454,'Exploratory deterministic trials. Shared histories and repeated anchors are not independent samples.',862,13.8,MUTED)
footer('Project data: Forge-Budget-V1-20260915. Raw logs and archived sources retained.','A2')

REFS=[
 ('[1] Whitney, D. E. (1982)','Quasi-Static Assembly of Compliantly Supported Rigid Parts.',
  'Journal of Dynamic Systems, Measurement, and Control 104(1):65-77.',
  'https://doi.org/10.1115/1.3149634'),
 ('[2] Goli, F., et al. (2024)','Characterizing the mechanics of rectangular peg-hole disassembly and the effect of the active compliance centre on the extraction force.',
  'Royal Society Open Science 11:240956.', 'https://doi.org/10.1098/rsos.240956'),
 ('[3] Hogan, N. (1985)','Impedance Control: An Approach to Manipulation: Part I - Theory.',
  'Journal of Dynamic Systems, Measurement, and Control 107(1):1-7.', 'https://doi.org/10.1115/1.3140702'),
 ('[4] Posa, M., Cantu, C., and Tedrake, R. (2014)','A direct method for trajectory optimization of rigid bodies through contact.',
  'International Journal of Robotics Research 33(1):69-81.', 'https://doi.org/10.1177/0278364913506757'),
 ('[5] Ames, A. D., Xu, X., Grizzle, J. W., and Tabuada, P. (2017)','Control Barrier Function Based Quadratic Programs for Safety Critical Systems.',
  'IEEE Transactions on Automatic Control 62(8):3861-3876.', 'https://doi.org/10.1109/TAC.2016.2638961'),
 ('[6] Tang, B., et al. (2023)','IndustReal: Transferring Contact-Rich Assembly Tasks from Simulation to Reality.',
  'Robotics: Science and Systems XIX.', 'https://arxiv.org/abs/2305.17110'),
 ('[7] Narang, Y., et al. (2022)','Factory: Fast Contact for Robotic Assembly.',
  'Robotics: Science and Systems XVIII.', 'https://arxiv.org/abs/2205.03532'),
 ('[8] Wabersich, K. P., and Zeilinger, M. N. (2021)','A predictive safety filter for learning-based control of constrained nonlinear dynamical systems.',
  'Automatica 129:109597.', 'https://doi.org/10.1016/j.automatica.2021.109597'),
 ('[9] Robotiq (2020)','2F-85 & 2F-140 Adaptive Grippers: Instruction Manual.',
  'Sections 4.5.1 (force control) and 5.2.1 (friction-grip capacity).',
  'https://assets.robotiq.com/website-assets/support_documents/document/2F-85_2F-140_General_PDF_20200211.pdf'),
 ('[10] Health and Safety Executive (2006)','The safe isolation of plant and equipment.',
  'HSG253, 2nd edition, Appendix 2: release of mechanical potential energy.',
  'https://www.hse.gov.uk/pubns/priced/hsg253.pdf')]
for part in range(2):
    start('References'+('' if part==0 else ' continued'),'Appendix '+('C' if part==0 else 'D'),'',True)
    for j,(author,title,venue,url) in enumerate(REFS[5*part:5*part+5]):
        y=103+j*79
        text(48,y,author,14.2,NAVY,True)
        ht=para(48,y+23,escape(title),862,12.4,NAVY,leading=16)
        para(48,y+24+ht,escape(venue)+f' <link href="{url}" color="#008D84">DOI / paper</link>',862,11.2,MUTED)
        if j<4:line(48,y+73,911,y+73)
    footer('Primary literature supports the research context and proposed methods. It does not validate local simulated force values.', 'A'+str(part+3))

C.save()

# Embed each chart PDF as vector objects onto its reserved slide area.
reader=PdfReader(BASE_PDF);writer=PdfWriter()
for page in reader.pages:writer.add_page(page)
for placement in PLACEMENTS:
    src=PdfReader(placement['path']).pages[0]
    transform=Transformation().scale(placement['scale']).translate(placement['x'],placement['y'])
    writer.pages[placement['page']].merge_transformed_page(src,transform,over=True)
writer.add_metadata({'/Title':'Preventing Insertion-Induced Jamming',
                     '/Author':'Franka Safe Recovery Research Project',
                     '/Subject':'12-slide, 10-minute research briefing: physical motivation, prevention methods and force-limited recovery',
                     '/Keywords':'motion planning, control, peg-in-hole, jamming prevention, force-limited recovery'})
for page in PAGES:
    writer.add_outline_item(page['title'],page['number']-1)
final=OUT/'safe_recovery_motion_planning_control.pdf'
with final.open('wb') as stream:writer.write(stream)
manifest=dict(final_pdf=str(final),pages=len(PAGES),main_slides=12,appendix_pages=4,
              research_priority='First prevent insertion-induced jamming; then restore withdrawability under an operation-force budget.',
              planned_talk_seconds=sum(TIMES),slides=PAGES,chart_placements=PLACEMENTS,
              builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              pdf_sha256=hashlib.sha256(final.read_bytes()).hexdigest())
(BASE/'talk_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['final_pdf','pages','main_slides','appendix_pages','planned_talk_seconds']},indent=2))
