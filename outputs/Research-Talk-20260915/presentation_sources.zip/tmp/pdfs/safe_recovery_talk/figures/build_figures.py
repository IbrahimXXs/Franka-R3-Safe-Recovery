#!/usr/bin/env python3
"""Rebuild talk figures from immutable saved runs. No simulation or study mutation.

Run with the repository's franka-safe-recovery Python environment.
Each consumed insertion/recovery CSV is SHA-256 checked against run.json;
raw wrist vector norms and saved maxima are checked before plotting.
"""
from pathlib import Path
import csv, hashlib, json, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
V1 = ROOT/'outputs/Forge-Budget-V1-20260915'
A6 = ROOT/'outputs/Forge-Budget-Angle6-20260915'
NAVY = '#17324D'; TEAL = '#00877C'; RED = '#C64C4C'; GRAY = '#667888'; PALE = '#E9EEF3'; GOLD = '#AD712D'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':16,'axes.labelsize':17,
 'xtick.labelsize':15,'ytick.labelsize':15,'axes.titlesize':18,'legend.fontsize':13,
 'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#BCC7D0',
 'axes.labelcolor':NAVY,'text.color':NAVY,'xtick.color':NAVY,'ytick.color':NAVY,
 'pdf.fonttype':42, 'figure.facecolor':'white','axes.facecolor':'white',
 'savefig.facecolor':'white'})
MANIFEST = {'script':str(Path(__file__).relative_to(ROOT)), 'inputs':{}, 'figures':{},
 'signal':'Raw wrist reaction-force vector norm [N], not calibrated axial pull or finger squeeze',
 'budget_rule':'Recorded reference + all recovery phases: allow F <= B and torque <= 1 Nm; strict exceedance stops subsequent task stepping. Instantaneous overshoot remains visible.',
 'mean_definition':'Trailing 24-sample arithmetic mean (100 ms at 240 Hz), complete contiguous same-phase windows only; recovery t=0 excluded as copied state.',
 'recovery_comparison':'Independent policy processes with full recorded reference prefixes matched by source review; hidden solver state not certified.',
 'censoring':'Stopped branch observed peaks are lower bounds on unobserved complete-motion peaks; no extrapolated samples.'}
RUN_CACHE = {}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def track(p):
 MANIFEST['inputs'][str(p.relative_to(ROOT))] = sha(p)
 return p

def run(study, cid, policy='straight'):
 key=(str(study),cid,policy)
 if key in RUN_CACHE:return RUN_CACHE[key]
 p=study/'runs'/cid/policy/'run.json'
 r=json.loads(track(p).read_text()); payload={}
 for seg,filename in [('reference','insertion.csv'),('recovery','recovery.csv')]:
  q=p.parent/filename
  if not q.exists():payload[seg]=[]; continue
  assert sha(q)==r['artifact_sha256'][filename],q
  rows=list(csv.DictReader(track(q).open()))
  for row in rows:
   f=float(row['wrist_force_n'])
   norm=math.sqrt(sum(float(row[f'wrist_raw_child_{i}'])**2 for i in range(3)))
   assert math.isclose(f,norm,abs_tol=3e-6,rel_tol=3e-6),(q,f,norm)
  if rows:
   peak=max(float(row['wrist_force_n']) for row in rows)
   metric='reference_peak_wrist_force_n' if seg=='reference' else 'max_wrist_force_n'
   assert math.isclose(peak,r[seg]['metrics'][metric],abs_tol=1e-10),(q,peak)
  payload[seg]=rows
 payload['run']=r;RUN_CACHE[key]=payload;return payload

def save(fig,name,details):
 fig.savefig(HERE/f'{name}.png',dpi=200)
 fig.savefig(HERE/f'{name}.pdf')
 plt.close(fig)
 MANIFEST['figures'][name]={'files':[f'{name}.png',f'{name}.pdf'],**details}

def style(ax):
 ax.grid(axis='y',color='#DCE3E9',lw=.7,zorder=0)
 ax.set_axisbelow(True)
 ax.tick_params(length=3)

def mean100(rows,hz=240):
 win=[];out=[];prev=None;phase=None
 for row in rows:
  t=float(row.get('recovery_time_s') or row['time_s'])
  if row['phase']!=phase or (prev is not None and abs(t-prev-1/hz)>1e-6):win=[]
  phase=row['phase'];prev=t
  if row.get('recovery_time_s')=='0.0':out.append(np.nan);continue
  win.append(float(row['wrist_force_n']));win=win[-24:]
  out.append(float(np.mean(win)) if len(win)==24 else np.nan)
 return out

MAIN='m_d18_fs100_fd100_a1p5__b04'
pair_path=ROOT/'outputs/Forge-Budget-V1-20260915-review/paired.csv'
pair=[r for r in csv.DictReader(track(pair_path).open()) if r['condition_id']==MAIN][0]
assert pair['replay_prefix_equal']=='True' and pair['observed_prefixes_matched']=='True'
straight=run(V1,MAIN);realign=run(V1,MAIN,'realign')
# 1: main paired recovery curves. Each x axis ends at its actually recorded outcome.
fig,axs=plt.subplots(1,2,figsize=(12,4.55),gridspec_kw={'wspace':.22})
for ax,payload,label in zip(axs,[straight,realign],['Direct withdrawal','Recenter + realign, then withdraw']):
 rows=payload['recovery'];t=np.array([float(r['recovery_time_s']) for r in rows]);f=np.array([float(r['wrist_force_n']) for r in rows])
 for phase,color in [('stop','#EEF1F5'),('realign','#E5F3F0'),('retreat','#FFFFFF')]:
  tt=[float(r['recovery_time_s']) for r in rows if r['phase']==phase]
  if tt:ax.axvspan(max(0,min(tt)-1/240),max(tt),color=color,zorder=0)
 ax.plot(t,f,color=NAVY,lw=1.0,alpha=.8,label='Raw norm')
 ax.plot(t,mean100(rows),color=TEAL,lw=2.0,label='100 ms mean')
 ax.axhline(4,color=RED,ls=(0,(5,3)),lw=1.5,label='4 N budget')
 ax.set(xlim=(0,max(t)*1.035),ylim=(0,5.2),xlabel='Own recovery time (s)',title=label)
 ax.set_yticks([0,1,2,3,4,5]);style(ax)
 if payload is straight:
  ax.scatter([t[-1]],[f[-1]],marker='X',s=80,color=RED,zorder=4)
  ax.annotate('4.54 N\nStopped at 0.721 s',xy=(t[-1],f[-1]),xytext=(.30,4.72),fontsize=13,color=RED,
   arrowprops={'arrowstyle':'-','color':RED,'lw':1},ha='center',va='center')
  ax.text(.02,.57,'STOP',transform=ax.transAxes,fontsize=12,color=GRAY)
  ax.text(.42,.57,'WITHDRAW',transform=ax.transAxes,fontsize=12,color=GRAY)
 else:
  ax.text(.98,.90,'3.75 N overall peak\n1.15 N during withdrawal',ha='right',va='top',transform=ax.transAxes,fontsize=13,color=TEAL,
   bbox={'facecolor':'white','edgecolor':'none','alpha':.94,'pad':2})
  ax.text(.12,.57,'REALIGN',transform=ax.transAxes,fontsize=12,color=GRAY)
  ax.text(.62,.57,'WITHDRAW',transform=ax.transAxes,fontsize=12,color=GRAY)
axs[0].set_ylabel('Wrist-force norm (N)')
fig.legend(handles=[Line2D([0],[0],color=NAVY,lw=1.4,label='Raw norm'),Line2D([0],[0],color=TEAL,lw=2,label='100 ms mean'),Line2D([0],[0],color=RED,lw=1.5,ls='--',label='Budget')],loc='lower center',bbox_to_anchor=(.5,.025),ncol=3,frameon=False)
fig.subplots_adjust(left=.075,right=.985,top=.87,bottom=.25)
save(fig,'paired_recovery_force',{'study':V1.name,'condition':MAIN,'same_force_scale':True,'independent_time_scales':True,
 'straight_observed_peak_n':max(float(r['wrist_force_n']) for r in straight['recovery']),
 'realign_complete_peak_n':max(float(r['wrist_force_n']) for r in realign['recovery'])})

# 2: no numeric zero for unexecuted recovery; censored observed peak is explicit.
fig,axs=plt.subplots(1,3,figsize=(12,4.4),sharey=True,gridspec_kw={'wspace':.16})
budget_details=[]
for ax,B in zip(axs,[3,4,5]):
 cid=f'm_d18_fs100_fd100_a1p5__b0{B}'
 p=run(V1,cid);r=p['run'];style(ax)
 ax.set_title(f'{B} N budget',fontweight='bold')
 ax.axhline(B,color=RED,lw=1.2,ls='--')
 ax.set(xlim=(-.6,1.6),ylim=(0,5.6),xticks=[0,1],xticklabels=['Direct','Realign'])
 ax.set_yticks([0,1,2,3,4,5])
 if B==3:
  peak=r['reference']['metrics']['reference_peak_wrist_force_n']
  ax.text(.5,.60,'Recovery\nnot executed',ha='center',va='center',transform=ax.transAxes,fontsize=18,color=GRAY,bbox={'facecolor':'white','edgecolor':'none','pad':2})
  ax.text(.5,.22,f'Reference exceeded:\n{peak:.2f} N',ha='center',transform=ax.transAxes,fontsize=14,color=GOLD)
  budget_details.append({'budget_n':B,'reference_peak_n':peak,'recovery':None})
 else:
  pp=run(V1,cid,'realign');peaks=[r['recovery']['metrics']['max_wrist_force_n'],pp['run']['recovery']['metrics']['max_wrist_force_n']]
  for x,v in enumerate(peaks):
   fail=B==4 and x==0
   ax.bar(x,v,width=.6,color=RED if fail else TEAL,alpha=.9,zorder=2)
   ax.text(x,v+.12,f'{v:.2f}'+('*' if fail else ''),ha='center',va='bottom',fontsize=17,color=RED if fail else TEAL,fontweight='bold',bbox={'facecolor':'white','edgecolor':'none','pad':1})
   ax.text(x,.15,'Stopped' if fail else 'Cleared',ha='center',va='bottom',fontsize=12,color='white',fontweight='bold')
  budget_details.append({'budget_n':B,'direct_observed_peak_n':peaks[0],'realign_complete_peak_n':peaks[1], 'direct_censored':B==4})
axs[0].set_ylabel('Observed recovery peak (N)')
fig.text(.5,.025,'* First-exceedance stop; complete direct-withdrawal peak remains unobserved.',ha='center',fontsize=13,color=GRAY)
fig.subplots_adjust(left=.075,right=.985,top=.84,bottom=.19)
save(fig,'budget_comparison',{'study':V1.name,'budgets':budget_details})

# 3: compact eight-condition matrix. Reference rejection and untested branches are distinct.
plan=json.loads(track(V1/'plan.json').read_text()) if (V1/'plan.json').exists() else None
bp=ROOT/'outputs/Forge-Budget-V1-20260915-review/branches.csv'
branches=list(csv.DictReader(track(bp).open()))
order=list(dict.fromkeys(r['condition_id'] for r in branches))
fig,ax=plt.subplots(figsize=(12,5.4));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
colxs=[.01,.10,.19,.28,.40,.72]
for x,label in zip(colxs,['Depth','μ','Tilt','Budget','Direct withdrawal','Recenter + realign']):ax.text(x,.96,label,fontsize=15,fontweight='bold',va='center')
styles={'clear_safe':('#DDF0EA',TEAL,'Clear within budget'), 'recovery_budget_exceeded':('#F9E3E1',RED,'Exceeded in withdrawal'),
 'reference_budget_exceeded':('#F5ECD9',GOLD,'Exceeded in reference'), 'not_tested':('#EDF0F3',GRAY,'Not tested')}
for i,cid in enumerate(order):
 y=.855-i*.099; s=next(r for r in branches if r['condition_id']==cid and r['policy']=='straight')
 for x,key,unit in zip(colxs[:4],['target_depth_mm','pair_static_friction','tilt_amplitude_deg','force_budget_n'],[' mm','','°',' N']):
  ax.text(x,y,f'{float(s[key]):g}{unit}',va='center',fontsize=15)
 for j,policy in enumerate(['straight','realign']):
  br=next(r for r in branches if r['condition_id']==cid and r['policy']==policy)
  if br['status']=='complete':
   payload=run(V1,cid,policy)
   assert payload['run']['outcome']['outcome']==br['outcome']
  color,fg,label=styles[br['outcome'] or 'not_tested']
  xx=colxs[4+j];ax.add_patch(Rectangle((xx-.015,y-.040),.29,.079,facecolor=color,edgecolor='white'))
  ax.text(xx+.13,y,label,ha='center',va='center',fontsize=13.5,color=fg,fontweight='bold')
 ax.axhline(y-.048,xmin=0,xmax=1,color='#EBEFF3',lw=.5)
fig.subplots_adjust(left=.015,right=.99,top=.98,bottom=.03)
save(fig,'condition_outcomes',{'study':V1.name,'condition_count':8,'executed_branches':13,'unexecuted_branches':3,
 'counts':{'clear_within_budget':9,'recovery_exceeded':1,'reference_exceeded':3}})

# 4: angle scan distinguishes target commands from terminal measured state.
ap=ROOT/'outputs/Forge-Budget-Angle6-20260915-review/angle_attainment.csv'
a=list(csv.DictReader(track(ap).open()))
for row in a:
 payload=run(A6,row['condition_id'])
 m=payload['run']['reference']['metrics']
 assert math.isclose(float(row['terminal_actual_tilt_deg']),m['terminal_actual_tilt_deg'],abs_tol=1e-12)
xs=np.arange(len(a));targets=np.array([float(r['tilt_amplitude_deg']) for r in a]);actual=np.array([float(r['terminal_actual_tilt_deg']) for r in a]);forces=np.array([float(r['reference_observed_peak_wrist_force_n']) for r in a])
fig,axs=plt.subplots(1,2,figsize=(12,4.5),gridspec_kw={'wspace':.27})
ax=axs[0];style(ax)
ax.plot(targets,targets,color=GRAY,lw=1.4,ls='--',label='Target command')
ax.plot(targets,actual,color=NAVY,lw=1.3,marker='o',ms=7,label='Terminal actual tilt')
ax.scatter(targets[1:],actual[1:],color=RED,s=42,zorder=4)
for x,y in zip(targets,actual):ax.annotate(f'{y:.2f}°',(x,y),xytext=(0,10),textcoords='offset points',ha='center',fontsize=12,color=NAVY)
ax.set(xlabel='Target tilt (deg)',ylabel='Tilt angle (deg)',ylim=(0,6.6),xlim=(1.15,6.35),xticks=[1.5,2,3,4,5,6],yticks=[0,2,4,6])
ax.legend(loc='upper left',frameon=False,fontsize=13)
ax=axs[1];style(ax)
ax.bar(xs,forces,color=[TEAL]+[RED]*5,width=.65,zorder=2)
ax.axhline(4,color=RED,lw=1.3,ls='--')
for x,v in zip(xs,forces):ax.text(x,v+.12,f'{v:.2f}',ha='center',fontsize=14,fontweight='bold')
ax.set(xlabel='Target tilt (deg)',ylabel='Reference peak norm (N)',xticks=xs,xticklabels=[f'{v:g}' for v in targets],ylim=(0,10),yticks=[0,2,4,6,8,10])
ax.text(.02,.96,'4 N budget',va='top',transform=ax.transAxes,fontsize=13,color=RED)
fig.text(.5,.025,'2°–6° commands: stopped during tilt, before withdrawal. Fixed 1 s ramp also changes angular speed.',ha='center',fontsize=13,color=GRAY)
fig.subplots_adjust(left=.065,right=.99,top=.94,bottom=.22)
save(fig,'angle_scan',{'study':A6.name,'target_deg':targets.tolist(),'terminal_actual_deg':actual.tolist(),'reference_observed_peak_n':forces.tolist(), 'ramp_duration_s':1.0})

# 5: displacement at main straight stop, useful as compact evidence of restricted progress.
rows=straight['recovery'];t=np.array([float(r['recovery_time_s']) for r in rows]);refd=float(straight['reference'][-1]['depth_mm']);actualw=np.array([refd-float(r['depth_mm']) for r in rows]);cmd=np.array([float(r['command_withdrawal_mm']) for r in rows])
fig,ax=plt.subplots(figsize=(7.5,3.4));style(ax)
ax.axvspan(0,.25,color='#EEF1F5');ax.plot(t,cmd,color=NAVY,lw=2,ls='--',label='Commanded');ax.plot(t,actualw,color=TEAL,lw=2,label='Measured')
ax.scatter([t[-1]],[actualw[-1]],color=RED,s=40,zorder=4)
ax.set(xlabel='Recovery time (s)',ylabel='Withdrawal (mm)',xlim=(0,.82),ylim=(-.05,1.32))
ax.text(.75,1.16,f'{cmd[-1]:.3f} mm',color=NAVY,fontsize=14,ha='right')
ax.text(.75,.24,f'{actualw[-1]:.3f} mm',color=TEAL,fontsize=14,ha='right')
ax.legend(frameon=False,loc='upper left',fontsize=13)
fig.subplots_adjust(left=.14,right=.98,top=.96,bottom=.25)
save(fig,'restricted_progress',{'study':V1.name,'condition':MAIN,'commanded_withdrawal_at_stop_mm':cmd[-1], 'measured_withdrawal_from_reference_endpoint_mm':actualw[-1],'stop_time_s':t[-1]})

# 6: depth comparison is descriptive, with the actual reference tilts disclosed.
fig,ax=plt.subplots(figsize=(8.2,4.25));style(ax)
values=[];tilts=[]
for depth in [12,18]:
 cid=f'm_d{depth}_fs100_fd100_a1p5__b04'
 vals=[]
 for policy in ['straight','realign']:
  payload=run(V1,cid,policy)
  vals.append(payload['run']['recovery']['metrics']['max_wrist_force_n'])
 values.append(vals)
 tilts.append(run(V1,cid)['run']['reference']['metrics']['terminal_actual_tilt_deg'])
for i,(depth,vals) in enumerate(zip([12,18],values)):
 for j,val in enumerate(vals):
  x=i+(-.19 if j==0 else .19)
  censored=i==1 and j==0
  col=NAVY if j==0 else TEAL
  ax.bar(x,val,width=.31,color=col,alpha=.92,zorder=2,hatch='///' if censored else None,edgecolor=RED if censored else col,linewidth=1.4)
  ax.text(x,val+.13,f'{val:.2f}'+('*' if censored else ''),ha='center',fontsize=16,color=RED if censored else col,fontweight='bold',bbox={'facecolor':'white','edgecolor':'none','pad':1})
ax.axhline(4,color=RED,ls='--',lw=1.4)
ax.set(xticks=[0,1],xticklabels=['12 mm','18 mm'],xlabel='Target insertion depth',ylabel='Observed recovery peak (N)',ylim=(0,5.4),xlim=(-.5,1.5),yticks=[0,1,2,3,4,5])
ax.legend(handles=[Rectangle((0,0),1,1,color=NAVY,label='Direct withdrawal'),Rectangle((0,0),1,1,color=TEAL,label='Recenter + realign')],loc='upper left',frameon=False,fontsize=13)
fig.text(.5,.023,'* Censored at budget exceedance. Actual initial tilt: 1.52° / 1.44°.',ha='center',fontsize=12.5,color=GRAY)
fig.subplots_adjust(left=.12,right=.985,top=.97,bottom=.23)
save(fig,'depth_comparison',{'study':V1.name,'target_depth_mm':[12,18],'actual_reference_tilt_deg':tilts,'recovery_peaks_n':{'direct':[v[0] for v in values],'realign':[v[1] for v in values]},'interpretation':'Descriptive depth contrast; endpoint states differ. Deep direct branch peak is right-censored.'})

MANIFEST['script_sha256']=sha(Path(__file__))
for name,entry in MANIFEST['figures'].items():entry['sha256']={f:sha(HERE/f) for f in entry['files']}
(HERE/'figure_manifest.json').write_text(json.dumps(MANIFEST,indent=2)+'\n')
print(json.dumps({'figures':list(MANIFEST['figures']),'verified_inputs':len(MANIFEST['inputs'])},indent=2))
