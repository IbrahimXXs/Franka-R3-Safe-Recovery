# Recorded-state simulation visuals

Four 1920 × 1080 PNG images are replay renderings from the measured trajectories of `m_d18_fs100_fd100_a1p5__b04`, realign policy. They use the existing FORGE robot, peg, socket and table assets. The socket override is byte-identical to the archived case. Original visual materials are retained: peg color is a rendering material, not a claim about the physical material.

| Image | Recorded state | Actual depth | Actual tilt |
|---|---|---:|---:|
| `bench_reference.png` | Reference endpoint, wide view | 18.228 mm | 1.439° |
| `closeup_reference.png` | Reference endpoint | 18.228 mm | 1.439° |
| `closeup_realigned.png` | End of recentering/uprighting | 18.076 mm | 0.170° |
| `closeup_clear.png` | End of successful withdrawal | −3.009 mm | 0.063° |

Suggested caption: **Recorded-state replay in Isaac Sim; visualization only.**

All closeups share one camera, scale and lighting. No angle or clearance is visually exaggerated. The renderer sets seven arm joints, two finger joints and peg pose from the CSV. The fixed socket retains the audited pose. The peg pose is recovered from recorded hand and grasp transforms, then checked against socket-relative measurements to < 0.0001 mm. No physics time advances between image captures, so these pictures do not add new dynamic results.

`provenance.json` contains source hashes, selected CSV times, camera settings and authored peg poses; `replay_audit.json` records verification. `render_recorded_scene.py` is the reproducible capture helper. It runs with the existing conda environment and `--headless --enable_cameras`. `audit_replay.py` checks the saved artifacts without loading Isaac Sim.
