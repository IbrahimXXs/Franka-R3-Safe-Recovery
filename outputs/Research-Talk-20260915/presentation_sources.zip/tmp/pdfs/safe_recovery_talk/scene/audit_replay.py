"""Check rendered-state metadata against the immutable recorded trajectories."""
import csv
import hashlib
import json
from pathlib import Path

DEST=Path(__file__).resolve().parent
ROOT=DEST.parents[3]
SOURCE=ROOT/'outputs/Forge-Budget-V1-20260915/runs/m_d18_fs100_fd100_a1p5__b04/realign'
metadata=json.loads((DEST/'provenance.json').read_text())
rows=list(csv.DictReader((SOURCE/'recovery.csv').open()))
states={'bench_reference':rows[0],'closeup_reference':rows[0],
        'closeup_realigned':next(r for r in reversed(rows) if r['phase']=='realign'),
        'closeup_clear':rows[-1]}
checks=[]
for name,row in states.items():
    expected=[.6+float(row['tip_x_mm'])/1000,float(row['tip_y_mm'])/1000,
              .075-float(row['depth_mm'])/1000]
    got=metadata['frames'][name]['peg_root_world_pose_wxyz']
    error=max(abs(a-b) for a,b in zip(expected,got[:3]))
    assert error<1e-7
    assert got[3:]==[float(row[k]) for k in ['qw','qx','qy','qz']]
    checks.append({'frame':name,'peg_position_max_abs_error_m':error,
                   'png_sha256':hashlib.sha256((DEST/f'{name}.png').read_bytes()).hexdigest()})
for source,sha in metadata['source_files'].items():
    assert hashlib.sha256((ROOT/source).read_bytes()).hexdigest()==sha
geom=Path('geometry/socket_radial_0.200000mm.usda')
assert (SOURCE/geom).read_bytes()==(DEST/geom).read_bytes()
clocks={frame['physics_time_s'] for frame in metadata['frames'].values()}
assert len(clocks)==1
result={'status':'passed','frames':checks,'socket_override_exactly_matches_archived':True,
        'all_capture_physics_clocks_identical':True,'physics_time_s':next(iter(clocks)),
        'clock_note':'Engine initialization advances the clock; no physics time advances during the four capture operations.',
        'limitations':['Readback audit covers authored peg world pose and source hashes. Robot links are reconstructed by the simulator from recorded arm/finger joint positions; no new force measurements were made.']}
(DEST/'replay_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
