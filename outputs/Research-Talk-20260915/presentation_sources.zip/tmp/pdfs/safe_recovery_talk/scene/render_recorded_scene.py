"""Static recorded-state replay: no dynamic experiment or force recomputation."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
DEST = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'simulation'))
from isaaclab.app import AppLauncher
parser = argparse.ArgumentParser()
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
args.physics_hz = 240
args.seed = 20260913
args.stock_buffers = False
args.radial_clearance_mm = .2
args.output_dir = DEST
app = AppLauncher(args).app

import torch
import numpy as np
from PIL import Image
import isaaclab.sim as sim_utils
from isaaclab.sensors import Camera, CameraCfg
from isaaclab.utils.math import quat_apply
from forge_backend import Bench

SOURCE = ROOT/'outputs/Forge-Budget-V1-20260915/runs/m_d18_fs100_fd100_a1p5__b04'
def read(policy, name):
    path=SOURCE/policy/name
    return list(csv.DictReader(path.open()))

try:
    bench=Bench(args,app)
    camera=Camera(CameraCfg(prim_path='/World/TalkCamera',width=1920,height=1080,
        update_period=0,data_types=['rgb'],spawn=sim_utils.PinholeCameraCfg(
            focal_length=24.,horizontal_aperture=30.,clipping_range=(.001,100.))))
    bench.sim.reset()
    rows=read('realign','recovery.csv')
    states={
      'reference':rows[0],
      'realigned':next(r for r in reversed(rows) if r['phase']=='realign'),
      'clear':rows[-1],
    }
    metadata={'description':'Static replay of recorded arm/finger joint states and peg pose in the original FORGE scene. No dynamics steps after setting states. Images are illustrative renderings, not additional force measurements.',
      'condition':'m_d18_fs100_fd100_a1p5__b04','source_files':{},'frames':{}}
    for file in [SOURCE/'realign/recovery.csv',SOURCE/'realign/scene.json',Path(__file__)]:
        metadata['source_files'][str(file.relative_to(ROOT))]=hashlib.sha256(file.read_bytes()).hexdigest()
    def apply_state(row):
        e=bench.env
        q=torch.tensor([[float(row[f'joint{i}_rad']) for i in range(1,8)]+
                        [float(row[f'finger_position_{i}']) for i in range(2)]],device=bench.device)
        e._robot.write_joint_state_to_sim(q,torch.zeros_like(q))
        hole=e._fixed_asset.data.default_root_state.clone()
        hole[:,:3]=torch.tensor([[.6,0.,.05]],device=bench.device)
        hole[:,3:7]=torch.tensor([[1.,0.,0.,0.]],device=bench.device)
        hole[:,7:]=0
        e._fixed_asset.write_root_state_to_sim(hole)
        hand=torch.tensor([[float(row[f'hand_pose_{i}']) for i in range(7)]],device=bench.device)
        grip=torch.tensor([[float(row[f'grasp_position_{i}']) for i in range(3)]],device=bench.device)
        peg=e._held_asset.data.default_root_state.clone()
        peg[:,:3]=hand[:,:3]+quat_apply(hand[:,3:],grip)
        peg[:,3:7]=torch.tensor([[float(row[k]) for k in ['qw','qx','qy','qz']]],device=bench.device)
        peg[:,7:]=0
        e._held_asset.write_root_state_to_sim(peg)
        bench.sim.forward()
        return peg[:,:7].cpu().tolist()[0]
    def capture(name,row,eye,target):
        pose=apply_state(row)
        camera.set_world_poses_from_view(torch.tensor([eye],device=bench.device),
                                         torch.tensor([target],device=bench.device))
        for _ in range(32):
            bench.sim.render()
        camera.update(bench.dt,force_recompute=True)
        rgb=camera.data.output['rgb'][0].cpu().numpy()
        Image.fromarray(rgb[:,:,:3]).save(DEST/f'{name}.png')
        metadata['frames'][name]={'recorded_phase':row['phase'],'recorded_time_s':float(row['time_s']),
          'recorded_depth_mm':float(row['depth_mm']),'recorded_tilt_deg':float(row['tilt_deg']),
          'peg_root_world_pose_wxyz':pose,'eye':eye,'target':target,'physics_time_s':bench.sim.current_time}
        (DEST/'provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
        print('SAVED',name,pose,flush=True)
    capture('bench_reference',states['reference'],(1.15,-1.15,.8),(.25,0.,.2))
    capture('closeup_reference',states['reference'],(.685,-.13,.14),(.6,0.,.075))
    capture('closeup_realigned',states['realigned'],(.685,-.13,.14),(.6,0.,.075))
    capture('closeup_clear',states['clear'],(.685,-.13,.14),(.6,0.,.075))
finally:
    sim=sim_utils.SimulationContext.instance()
    if sim:
        sim.clear_all_callbacks();sim.clear_instance();sim.stop()
    app.close(wait_for_replicator=False)
